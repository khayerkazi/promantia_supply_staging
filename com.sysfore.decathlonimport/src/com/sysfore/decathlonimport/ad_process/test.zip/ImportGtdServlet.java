/*
 ******************************************************************************
 * The contents of this file are subject to the   Compiere License  Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * You may obtain a copy of the License at http://www.compiere.org/license.html
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is                  Compiere  ERP & CRM  Business Solution
 * The Initial Developer of the Original Code is Jorg Janke  and ComPiere, Inc.
 * Portions created by Jorg Janke are Copyright (C) 1999-2001 Jorg Janke, parts
 * created by ComPiere are Copyright (C) ComPiere, Inc.;   All Rights Reserved.
 * Contributor(s): Openbravo SLU
 * Contributions are Copyright (C) 2001-2009 Openbravo S.L.U.
 ******************************************************************************
 */
package com.sysfore.decathlonimport.ad_process;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.openbravo.base.secureApp.HttpSecureAppServlet;
import org.openbravo.base.secureApp.VariablesSecureApp;
import org.openbravo.erpCommon.ad_actionButton.ActionButtonDefaultData;
import org.openbravo.erpCommon.utility.SequenceIdData;
import org.openbravo.erpCommon.utility.OBError;
import org.openbravo.erpCommon.utility.Utility;
import org.openbravo.xmlEngine.XmlDocument;

public class ImportGtdServlet extends HttpSecureAppServlet {
  private static final long serialVersionUID = 1L;
  int errmsg=0;
  public void init(ServletConfig config) {
    super.init(config);
    boolHist = false;
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,
      ServletException {
    VariablesSecureApp vars = new VariablesSecureApp(request);
    String process = "ImportGtd";// ImportData.processId(this, "ImportProduct");
    String strmInoutId = SequenceIdData.getUUID();	
  //  System.out.println(process);
    String message = "", docTargetType = "BBF08BB6DE414A3F8DC98D7902E5848E", strDocumentno="", docType="0"; 	
    if (vars.commandIn("DEFAULT")) {
      // System.out.println("Inside the Default Product");
      String strTabId = vars.getGlobalVariable("inpTabId", "ImportGtdServlet|tabId");
      String strWindowId = vars.getGlobalVariable("inpwindowId",
          "ImportGtdServlet|windowId");
      String strDeleteOld = vars.getStringParameter("inpDeleteOld", "Y");
      printPage(response, vars, process, strWindowId, strTabId, strDeleteOld);
    } else if (vars.commandIn("SAVE")) {
      // System.out.println("Inside the Purchase Order Save");
      String strDeleteOld = vars.getStringParameter("inpDeleteOld", "N");
      String strTabId = vars.getRequestGlobalVariable("inpTabId",
          "ImportGtdServlet|tabId");

      String strWindowPath = Utility.getTabURL(this, strTabId, "R");

      if (strWindowPath.equals(""))

      strWindowPath = strDefaultServlet;

      OBError myError = new OBError();

      String user = vars.getUser();
      String result = ImportGtd3Data.importgtd(this,user);		

      /*String result = "",docnum="", itemcode="", qty="",whouse="", loctor="", box="", strcOrderLineId="", mproduct="", locatoreid="", warehouseid="";
      String strDateReceipt = "";
      String strLastBpartnerId = "";
      String strLastOrgId = "";	
      String client = vars.getClient();
      String organistation = vars.getOrg();
      
      int recheck = 0, locount=0, ins=0, line=0, inmsd=1, inmt=0;
     System.out.println("code called ");
     ImportGtdData[] documentnodata=ImportGtdData.selectdocumentno(this, user);	
     if(documentnodata.length>0)
	{
			for(int g=0; g<documentnodata.length;g++){
			docnum=documentnodata[g].doc;
				 ImportGtd1Data[] getdata=ImportGtd1Data.selectdeatils(this, docnum);			
	    			 for(int i=0; i<getdata.length;i++)
					{
						itemcode=getdata[i].itemcode;
						qty=getdata[i].qty;
						whouse=getdata[i].warehouse;
						loctor=getdata[i].locator; 
						box=getdata[i].boxno;
						mproduct=ImportGtdData.getmproductid(this, itemcode);
						warehouseid=ImportGtdData.getwarehouse(this, whouse);
						locount=Integer.parseInt(ImportGtdData.selectlocator(this, box ));
						if(locount>0)
							{
							System.out.println("locator EXITS " + loctor + " loctor " + whouse + " whouse " + box + " box ");
							}
							else{
							System.out.println("creating new locator" + loctor + " loctor " + whouse + " whouse " + box + " box ");
							ins=ImportGtdData.insertlocator(this, loctor, whouse, box);
							     }

							locatoreid=ImportGtdData.getlocator(this, warehouseid, loctor, box);
					
					}	
							
	 }
	}
      ImportGtdData.deletefromtemp(this,user); // delete record from temp table*/
	
     if (result.equals("t")){
	//int va=ValidateGtdData.ValidateUpdate(this,user);
        myError.setType("Success");
        myError.setTitle(Utility.messageBD(this, "Success", vars.getLanguage()));
        myError.setMessage(Utility.messageBD(this, "Imported Successful", vars.getLanguage()));
      } else {
        myError.setType("Error");
        myError.setTitle(Utility.messageBD(this, "Error", vars.getLanguage()));
        myError.setMessage(Utility.messageBD(this, "Import Failure ! ", vars
            .getLanguage()));

      }
       vars.setSessionValue(strTabId + "|ImportGtd3273451C213B4D1BB7266346CCD6E4D7.view",
          "");
      vars.setMessage(strTabId, myError);
      // System.out.println("Result is " + result);	
      printPageClosePopUp(response, vars, strWindowPath);
    } else
      pageErrorPopUp(response);

  }

  private void printPage(HttpServletResponse response, VariablesSecureApp vars,
      String strProcessId, String strWindowId, String strTabId, String strDeleteOld)
      throws IOException, ServletException {
    if (log4j.isDebugEnabled())
      log4j.debug("Output: process ImportGtdServlet");
    ActionButtonDefaultData[] data = null;
    String strHelp = "", strDescription = "";
    /*
     * if (vars.getLanguage().equals("en_US")) { // data = ActionButtonDefaultData.select(this,
     * strProcessId); System.out.println("Inside English " + data.length); } else data =
     * ActionButtonDefaultData.selectLanguage(this, vars.getLanguage(), strProcessId); /* if (data
     * != null && data.length != 0) { strDescription = data[d].description; strHelp = data[d].help;
     * System.out.println(" StrDescription " + strDescription); System.out.println(" Strhelp " +
     * strHelp); }
     */
    String[] discard = { "" };
    if (strHelp.equals(""))
      discard[0] = new String("helpDiscard");
    XmlDocument xmlDocument = xmlEngine.readXmlTemplate(
        "com/sysfore/decathlonimport/ad_process/ImportGtdServlet").createXmlDocument();
    xmlDocument.setParameter("language", "defaultLang=\"" + vars.getLanguage() + "\";");
    xmlDocument.setParameter("directory", "var baseDirectory = \"" + strReplaceWith + "/\";\n");
    xmlDocument.setParameter("theme", vars.getTheme());
    xmlDocument.setParameter("question", Utility.messageBD(this, "StartProcess?", vars
        .getLanguage()));
    xmlDocument.setParameter("description", strDescription);
    xmlDocument.setParameter("help", strHelp);
    xmlDocument.setParameter("windowId", strWindowId);
    xmlDocument.setParameter("tabId", strTabId);
    xmlDocument.setParameter("deleteOld", strDeleteOld);

    response.setContentType("text/html; charset=UTF-8");
    PrintWriter out = response.getWriter();
    out.println(xmlDocument.print());
    out.close();
  }

  public String getServletInfo() {
    return "Servlet ImportGtdServlet";
  } // end of getServletInfo() method
}
