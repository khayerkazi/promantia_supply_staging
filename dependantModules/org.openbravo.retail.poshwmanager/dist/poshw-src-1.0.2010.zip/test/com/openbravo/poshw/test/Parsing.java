/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.test;

import com.openbravo.pos.util.StringParser;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author adrian
 */
public class Parsing {

    public Parsing() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

     @Test
     public void hello() {
         StringParser p = new StringParser("epson:file,/sdfsdfsf/dsfffs,1,2");
         System.out.println(p.nextToken(':'));
         System.out.println(p.nextToken(','));
         System.out.println(p.nextToken(Character.MIN_VALUE));
         System.out.println(p.nextToken(Character.MIN_VALUE));
         System.out.println(p.nextToken(Character.MIN_VALUE));
         

     }
     
     @Test
     public void HexaTest() {         
         assertEquals("fa8", Integer.toString((short) Integer.parseInt("0fa8", 16), 16));
         assertEquals("-5f70", Integer.toString((short) Integer.parseInt("a090", 16), 16));
         assertEquals("a090", Integer.toString(Integer.parseInt("a090", 16), 16));
     }     
}