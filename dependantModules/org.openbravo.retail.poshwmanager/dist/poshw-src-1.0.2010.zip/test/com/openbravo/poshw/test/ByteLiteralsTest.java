/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.openbravo.poshw.test;

import gnu.io.SerialPort;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;

/**
 *
 * @author adrian
 */
public class ByteLiteralsTest {

    public ByteLiteralsTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void hello() {

        byte b = (byte)0xff;
        System.out.println(Byte.valueOf(b));
        
        System.out.println(SerialPort.FLOWCONTROL_XONXOFF_IN | SerialPort.FLOWCONTROL_XONXOFF_OUT);
        System.out.println(SerialPort.FLOWCONTROL_RTSCTS_IN | SerialPort.FLOWCONTROL_RTSCTS_OUT);
     }
     @Test
     public void checksum() {
         byte a = (byte)0x00;
         byte b = (byte)0x20;
         byte c = (byte)0xcf;

        byte check = (byte)(a + b + (byte)0x11 + (byte)0x01 + c);
        System.out.println(check);
     }
     
     @Test
     public void byteConversions() {
         byte a = 0x00;
         byte b = 0x01 ;
         byte c = (byte)0xff;
         byte d = -0x01;

        Assert.assertEquals(0, (int) a);
        Assert.assertEquals(1, (int) b);
        Assert.assertEquals(-1, (int) c);
        Assert.assertEquals(-1, (int) d);
     }
}