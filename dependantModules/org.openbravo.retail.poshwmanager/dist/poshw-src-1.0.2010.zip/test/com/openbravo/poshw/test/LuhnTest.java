/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.test;

import com.openbravo.pos.util.LuhnAlgorithm;
import org.junit.Test;
import org.junit.Assert;

/**
 *
 * @author adrian
 */
public class LuhnTest {

    @Test
    public void luhnVerify() {
        Assert.assertTrue(LuhnAlgorithm.checkCC("4111111111111111")); // Visa
        Assert.assertTrue(LuhnAlgorithm.checkCC("5500000000000004")); // Master card
        Assert.assertTrue(LuhnAlgorithm.checkCC("340000000000009")); // AMEX
        Assert.assertTrue(LuhnAlgorithm.checkCC("30000000000004")); // Dinners
        Assert.assertTrue(LuhnAlgorithm.checkCC("30000000000004")); // Carte blanche
        Assert.assertTrue(LuhnAlgorithm.checkCC("6011000000000004")); // Discover
        Assert.assertTrue(LuhnAlgorithm.checkCC("201400000000009")); // EnRoute
        Assert.assertTrue(LuhnAlgorithm.checkCC("2131000000000008")); // JCB
        Assert.assertTrue(LuhnAlgorithm.checkCC("6334000000000004")); // Solo
        Assert.assertTrue(LuhnAlgorithm.checkCC("4903010000000009")); // Switch
    }
}
