/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.pos.payment.DevicePayment;
import com.openbravo.pos.payment.PaymentRequest;
import com.openbravo.pos.payment.PaymentResult;
import com.openbravo.pos.util.StringUtils;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author adrian
 */
public class PaymentServlet extends CORSHttpServlet  {

    private final DevicePayment device;

    public PaymentServlet(DevicePayment device) {
        this.device = device;
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response, new StringReader(request.getParameter("content")));
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response, request.getReader());
    }

    private void doProcess(HttpServletRequest request, HttpServletResponse response, Reader r) throws ServletException, IOException {

        setCORSHeaders(request, response);
        response.setContentType("application/json");

        try {
            String content = null;
            try {
                content = StringUtils.readReader(r);
            } finally {
                r.close();
            }
            
            PaymentRequest params = new PaymentRequest(new JSONObject(content));
            PaymentResult result = device.execute(params);

            response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), result.toJSON()));
        } catch (JSONException ex) {
            Logger.getLogger(TicketServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.getWriter().println(JSONUtils.getExceptionJSONP(request.getParameter("callback"), ex));
        }
    }
}
