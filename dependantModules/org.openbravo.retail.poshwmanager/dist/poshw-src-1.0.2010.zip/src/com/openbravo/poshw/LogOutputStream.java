/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 *
 * @author adrian
 */
public class LogOutputStream extends OutputStream {

    private JTextArea ui;
    private ByteArrayOutputStream buf;



    public LogOutputStream(JTextArea ui) {
        this.ui = ui;
        buf = new ByteArrayOutputStream();
    }

    public String getEncoding() {
        return "UTF-8";
    }

    @Override
    public void write(int b) throws IOException {
        if (buf == null) {
            return;
        }
        buf.write(b);
    }
    @Override
    public void write(byte b[], int off, int len) throws IOException {
        if (buf == null) {
            return;
        }
        buf.write(b, off, len);
    }
    @Override
    public void flush() {
        if (buf == null) {
            return;
        }

        if (buf.size() > 0) {
            try {
                SwingUtilities.invokeLater(new PrintText(buf.toString(getEncoding())));
            } catch (UnsupportedEncodingException ex) {
            }
            buf.reset();
        }
    }
    @Override
    public void close() {
        flush();
        buf = null;
        ui = null;
    }

    private class PrintText implements Runnable {
        private String txt;
        public PrintText(String txt) {
            this.txt = txt;
        }
        @Override
        public void run() {
            ui.insert(txt, ui.getDocument().getLength());
        }
    }
}
