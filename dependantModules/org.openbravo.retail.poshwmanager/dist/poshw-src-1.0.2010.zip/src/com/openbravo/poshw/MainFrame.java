/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.pos.payment.PaymentResult;
import com.openbravo.pos.printer.DeviceDisplayBase;
import com.openbravo.pos.printer.DeviceFiscalPrinter;
import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.JPanelPrinter;
import com.openbravo.pos.scale.ScaleException;
import com.openbravo.poshw.server.*;
import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import javax.swing.JOptionPane;
import org.codehaus.jettison.json.JSONException;

/**
 *
 * @author adrian
 */
public class MainFrame extends javax.swing.JFrame implements ServerListener {

    private static final Logger logger = Logger.getLogger(MainFrame.class.getName());

    private final NumberFormat nf = new DecimalFormat("#,##0.000");
    private final MainApp app;

    /** Creates new form MainFrame
     * @param app */
    public MainFrame(MainApp app) {

        this.app = app;

        initComponents();
        try {
            this.setIconImage(ImageIO.read(MainFrame.class.getResourceAsStream("/com/openbravo/poshw/images/favicon.png")));
        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
        }

        // Capturing log requests...
        LogOutputStream logout = new LogOutputStream(txtSrvLog);
        Logger.getLogger("com.openbravo").addHandler(new TextHandler(logout, logout.getEncoding(), Level.INFO));

        // About
        txtAbout.setText(License.LICENSE_HTML);
        lblversion.setText("version: " + this.app.getConfig().getProperty("application.version"));

        // Receipt printers & customer display
        StringBuilder s = new StringBuilder();
        int i = 1;
        for (DevicePrinter p : app.getDeviceTicket().getDevicePrinterAll()) {
            s.append("Receipt printer nº ");
            s.append(i);
            s.append(": ");
            s.append(p.getPrinterName());
            s.append(". ");
            s.append(p.getPrinterDescription());
            s.append("\n");
            i++;
        }
        btnTestPrinters.setEnabled(i > 1);
        btnTestDrawers.setEnabled(i > 1);
        btnResetPrinters.setEnabled(i > 1);

        s.append("Customer display: ");
        s.append(app.getDeviceTicket().getDeviceDisplay().getDisplayName());
        s.append(". ");
        s.append(app.getDeviceTicket().getDeviceDisplay().getDisplayDescription());
        txtPrinterStatus.setText(s.toString());
        logger.info(s.toString());

        containerPrinter.add(new JPanelPrinter(app.getDeviceTicket()), BorderLayout.CENTER);

        // Fiscal printers
        s = new StringBuilder();
        i = 1;
        for (DeviceFiscalPrinter f : app.getDeviceTicket().getFiscalPrinterAll()) {
            s.append("Fiscal printer nº ");
            s.append(i);
            s.append(": ");
            s.append(f.getFiscalName());
            s.append(". ");
            s.append(f.getFiscalDescription());
            s.append("\n");
            i++;
        }
        cmdTestFiscal.setEnabled(i > 1);
        cmdResetFiscal.setEnabled(i > 1);
        txtFiscalStatus.setText(s.toString());
        logger.info(s.toString());

        // Scale interface
        if (app.getDeviceTicket().getDeviceScale().getScaleComponent() != null) {
            containerScale.add(app.getDeviceTicket().getDeviceScale().getScaleComponent(), BorderLayout.CENTER);
        }
        s = new StringBuilder();
        s.append("Scale: ");
        s.append(app.getDeviceTicket().getDeviceScale().getScaleName());
        s.append(". ");
        s.append(app.getDeviceTicket().getDeviceScale().getScaleDescription());
        txtScaleStatus.setText(s.toString());
        logger.info(s.toString());
        
        // Payment interface
        if (app.getDeviceTicket().getDevicePayment().getComponent() != null) {
            containerPayment.add(app.getDeviceTicket().getDevicePayment().getComponent(), BorderLayout.CENTER);
        }
        s = new StringBuilder();
        s.append("Payment device: ");
        s.append(app.getDeviceTicket().getDevicePayment().getName());
        s.append(". ");
        s.append(app.getDeviceTicket().getDevicePayment().getDescription());
        txtPaymentStatus.setText(s.toString());
        logger.info(s.toString());        

        // configuration
        txtConfig.setText(app.getConfig().getText());

        printStatus();
    }

    public void init() {
        setVisible(true);
        app.getServer().setListener(this);
        app.getServer().start();
    }

    private void printStatus() {

        StringBuilder status = new StringBuilder();
        status.append(app.getServer().printName());
        status.append("\n");
        status.append(app.getServer().printStatus());
        txtSrvStatus.setText(status.toString());

        btnStart.setEnabled(app.getServer().getState() == ServerManager.STOPPED);
        btnStop.setEnabled(app.getServer().getState() == ServerManager.STARTED);
    }

    public void starting() {
        printStatus();
    }

    public void started() {
        printStatus();
    }

    public void failure() {
        printStatus();
    }

    public void stopping() {
        printStatus();
    }

    public void stopped() {
        printStatus();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        lblversion = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtAbout = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnStart = new javax.swing.JButton();
        btnStop = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtSrvStatus = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtSrvLog = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtConfig = new javax.swing.JTextArea();
        containerPrinter = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnTestPrinters = new javax.swing.JButton();
        btnTestDrawers = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtPrinterStatus = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        btnResetPrinters = new javax.swing.JButton();
        btnCheckDrawers = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        cmdTestFiscal = new javax.swing.JButton();
        cmdResetFiscal = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtFiscalStatus = new javax.swing.JTextArea();
        containerScale = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtScaleStatus = new javax.swing.JTextArea();
        btnTestScale = new javax.swing.JButton();
        containerPayment = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtPaymentStatus = new javax.swing.JTextArea();
        btnTestPayment = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("POS Hardware Manager");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        lblversion.setText("0.0.0");

        jLabel2.setFont(jLabel2.getFont().deriveFont(jLabel2.getFont().getStyle() | java.awt.Font.BOLD, jLabel2.getFont().getSize()+6));
        jLabel2.setText("Openbravo POS Hardware Manager ");

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/openbravo/poshw/images/poweredby.png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblversion)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 354, Short.MAX_VALUE)
                .addComponent(jLabel1))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblversion))
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtAbout.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtAbout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAbout, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("About", jPanel5);

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnStop.setText("Stop");
        btnStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopActionPerformed(evt);
            }
        });

        txtSrvStatus.setColumns(20);
        txtSrvStatus.setEditable(false);
        txtSrvStatus.setRows(5);
        jScrollPane1.setViewportView(txtSrvStatus);

        txtSrvLog.setColumns(20);
        txtSrvLog.setEditable(false);
        txtSrvLog.setRows(5);
        jScrollPane4.setViewportView(txtSrvLog);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnStart)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStop)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStart)
                    .addComponent(btnStop))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Web server", jPanel1);

        txtConfig.setColumns(20);
        txtConfig.setEditable(false);
        txtConfig.setRows(5);
        jScrollPane5.setViewportView(txtConfig);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 874, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 676, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 652, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        jTabbedPane1.addTab("Configuration", jPanel4);

        containerPrinter.setLayout(new java.awt.BorderLayout());

        btnTestPrinters.setText("Test printers");
        btnTestPrinters.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTestPrintersActionPerformed(evt);
            }
        });

        btnTestDrawers.setText("Test drawers");
        btnTestDrawers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTestDrawersActionPerformed(evt);
            }
        });

        jButton3.setText("Test display");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        txtPrinterStatus.setColumns(20);
        txtPrinterStatus.setEditable(false);
        txtPrinterStatus.setRows(5);
        jScrollPane2.setViewportView(txtPrinterStatus);

        jButton4.setText("Reset display");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        btnResetPrinters.setText("Reset printers");
        btnResetPrinters.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetPrintersActionPerformed(evt);
            }
        });

        btnCheckDrawers.setText("Check drawers");
        btnCheckDrawers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckDrawersActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnTestPrinters)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnTestDrawers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCheckDrawers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnResetPrinters)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTestPrinters)
                    .addComponent(btnTestDrawers)
                    .addComponent(btnResetPrinters)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(btnCheckDrawers))
                .addContainerGap())
        );

        containerPrinter.add(jPanel3, java.awt.BorderLayout.NORTH);

        jTabbedPane1.addTab("Printer", containerPrinter);

        jPanel7.setLayout(new java.awt.BorderLayout());

        cmdTestFiscal.setText("Test printers");
        cmdTestFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdTestFiscalActionPerformed(evt);
            }
        });

        cmdResetFiscal.setText("Reset printers");
        cmdResetFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdResetFiscalActionPerformed(evt);
            }
        });

        txtFiscalStatus.setColumns(20);
        txtFiscalStatus.setEditable(false);
        txtFiscalStatus.setRows(5);
        jScrollPane6.setViewportView(txtFiscalStatus);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(cmdTestFiscal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdResetFiscal)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmdTestFiscal)
                    .addComponent(cmdResetFiscal))
                .addContainerGap())
        );

        jPanel7.add(jPanel8, java.awt.BorderLayout.NORTH);

        jTabbedPane1.addTab("Fiscal printer", jPanel7);

        containerScale.setLayout(new java.awt.BorderLayout());

        txtScaleStatus.setEditable(false);
        txtScaleStatus.setColumns(20);
        txtScaleStatus.setRows(5);
        jScrollPane3.setViewportView(txtScaleStatus);

        btnTestScale.setText("Test scale");
        btnTestScale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTestScaleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addComponent(btnTestScale))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTestScale)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        containerScale.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jTabbedPane1.addTab("Scale", containerScale);

        containerPayment.setLayout(new java.awt.BorderLayout());

        txtPaymentStatus.setEditable(false);
        txtPaymentStatus.setColumns(20);
        txtPaymentStatus.setRows(5);
        jScrollPane7.setViewportView(txtPaymentStatus);

        btnTestPayment.setText("Test payment");
        btnTestPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTestPaymentActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addComponent(btnTestPayment))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTestPayment)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        containerPayment.add(jPanel9, java.awt.BorderLayout.PAGE_START);

        jTabbedPane1.addTab("Payment", containerPayment);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        
        app.getServer().stop();
        
        System.exit(0);

    }//GEN-LAST:event_formWindowClosed

    private void btnTestPrintersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTestPrintersActionPerformed

        try {
            BufferedImage img = ImageIO.read(getClass().getClassLoader().getResourceAsStream("com/openbravo/poshw/images/poweredby.png"));
            synchronized(app.getPrinterDocument()) {
                int i = 1;
                for (DevicePrinter printer1: app.getDeviceTicket().getDevicePrinterAll()) {
                    printer1.beginReceipt();
                    printer1.printImage(img);
                    printer1.beginLine(DevicePrinter.SIZE_0);
                    printer1.printText(DevicePrinter.STYLE_PLAIN, "");
                    printer1.endLine();
                    printer1.beginLine(DevicePrinter.SIZE_0);
                    printer1.printText(DevicePrinter.STYLE_PLAIN, "Testing the printer number: " + Integer.toString(i++) + ".");
                    printer1.endLine();
                    printer1.beginLine(DevicePrinter.SIZE_0);
                    printer1.printText(DevicePrinter.STYLE_PLAIN, "Thank you");
                    printer1.endLine();
                    printer1.endReceipt();
                }
                JOptionPane.showMessageDialog(this, "Verify that a sample text has been printed in all receipt printers.", "Receipt printers", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnTestPrintersActionPerformed

    private void btnTestDrawersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTestDrawersActionPerformed

        synchronized(app.getPrinterDocument()) {
            for (DevicePrinter printer1: app.getDeviceTicket().getDevicePrinterAll()) {
                printer1.openDrawer();
            }
            JOptionPane.showMessageDialog(this, "Verify that all cash drawers has been opened.", "Cash drawers", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btnTestDrawersActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        synchronized(app.getPrinterDocument()) {
            app.getDeviceTicket().getDeviceDisplay().writeVisor(DeviceDisplayBase.ANIMATION_SCROLL, "Testing the display", "Thank you");
            JOptionPane.showMessageDialog(this, "Verify that a sample text his shown in the customer display.", "Customer display", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed

        app.getServer().start();

    }//GEN-LAST:event_btnStartActionPerformed

    private void btnStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopActionPerformed

        app.getServer().stop();
        
    }//GEN-LAST:event_btnStopActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        if (JOptionPane.showConfirmDialog(this, "Do yo really want to reset the customer display?", "Customer display", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            synchronized(app.getPrinterDocument()) {
                app.getDeviceTicket().getDeviceDisplay().clearVisor();
            }
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void btnTestScaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTestScaleActionPerformed

        try {
            Double w = app.getDeviceTicket().getDeviceScale().readWeight();
            if (w == null) {
                JOptionPane.showMessageDialog(this, "WARNING: Result has been canceled by the scale.", "Scale test", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Weight: " + nf.format(w), "Scale test", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (ScaleException ex) {
            JOptionPane.showMessageDialog(this, "ERROR: " + ex.getMessage(), "Scale test", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnTestScaleActionPerformed

    private void btnResetPrintersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetPrintersActionPerformed

        if (JOptionPane.showConfirmDialog(this, "Do yo really want to reset all printers?", "Receipt printers", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            synchronized(app.getPrinterDocument()) {
                for (DevicePrinter printer1: app.getDeviceTicket().getDevicePrinterAll()) {
                    printer1.reset();
                }
            }
        }

    }//GEN-LAST:event_btnResetPrintersActionPerformed

    private void cmdTestFiscalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdTestFiscalActionPerformed

        try {
            synchronized(app.getPrinterDocument()) {
                for (DeviceFiscalPrinter p: app.getDeviceTicket().getFiscalPrinterAll()) {
                    p.test();
                }
                JOptionPane.showMessageDialog(this, "Verify that a sample text has been printed in all fiscal printers.", "Fiscal printers", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "An error occurred:\n" + ex.getMessage(), "Fiscal printers", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_cmdTestFiscalActionPerformed

    private void cmdResetFiscalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdResetFiscalActionPerformed

        try {
            if (JOptionPane.showConfirmDialog(this, "Do yo really want to reset all fiscal printers?", "Fiscal printers", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                synchronized(app.getPrinterDocument()) {
                    for (DeviceFiscalPrinter p: app.getDeviceTicket().getFiscalPrinterAll()) {
                        p.reset();
                    }
                }
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "An error occurred:\n" + ex.getMessage(), "Fiscal printers", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cmdResetFiscalActionPerformed

    private void btnCheckDrawersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckDrawersActionPerformed

        synchronized(app.getPrinterDocument()) {
            StringBuilder sb = new StringBuilder();
            for (DevicePrinter printer1: app.getDeviceTicket().getDevicePrinterAll()) {
                sb.append(printer1.getPrinterName());
                sb.append(": ");
                sb.append(printer1.checkDrawerStatus());
                sb.append("\n");
            }
            JOptionPane.showMessageDialog(this, "Verify the status of all drawers:\n" + sb.toString(), "Cash drawers", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnCheckDrawersActionPerformed

    private void btnTestPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTestPaymentActionPerformed

        PaymentDialog payDialog = new PaymentDialog(this);
        payDialog.setVisible(true);
        synchronized(app.getPrinterDocument()) {
            PaymentResult result = app.getDeviceTicket().getDevicePayment().execute(payDialog.getRequest());
            if (result == null) {
                JOptionPane.showMessageDialog(this, "Payment device returned null.", "Payment device result", JOptionPane.WARNING_MESSAGE);
            } else {
                try {
                    PaymentResultDialog resultdialog = new PaymentResultDialog(this, result.toJSON().toString(4));
                    resultdialog.setVisible(true);
                } catch (JSONException ex) {
                    logger.log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(this, "An error occurred:\n" + ex.getMessage(), "Payment device result", JOptionPane.ERROR_MESSAGE);;
                }
            }
        }       
    }//GEN-LAST:event_btnTestPaymentActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCheckDrawers;
    private javax.swing.JButton btnResetPrinters;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnStop;
    private javax.swing.JButton btnTestDrawers;
    private javax.swing.JButton btnTestPayment;
    private javax.swing.JButton btnTestPrinters;
    private javax.swing.JButton btnTestScale;
    private javax.swing.JButton cmdResetFiscal;
    private javax.swing.JButton cmdTestFiscal;
    private javax.swing.JPanel containerPayment;
    private javax.swing.JPanel containerPrinter;
    private javax.swing.JPanel containerScale;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblversion;
    private javax.swing.JLabel txtAbout;
    private javax.swing.JTextArea txtConfig;
    private javax.swing.JTextArea txtFiscalStatus;
    private javax.swing.JTextArea txtPaymentStatus;
    private javax.swing.JTextArea txtPrinterStatus;
    private javax.swing.JTextArea txtScaleStatus;
    private javax.swing.JTextArea txtSrvLog;
    private javax.swing.JTextArea txtSrvStatus;
    // End of variables declaration//GEN-END:variables

}
