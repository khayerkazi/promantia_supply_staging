/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.server;

import com.openbravo.poshw.AppConfig;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author adrian
 */
public interface ServerManager {

    public static final int STARTING = 0;
    public static final int STARTED = 1;
    public static final int STOPPED = 2;
    public static final int STOPPING = 3;
    public static final int FAILURE = 4;

    public void init(AppConfig config);
    public void addServlet(String path, HttpServlet servlet);
    public void setListener(ServerListener listener);
    public void start();
    public void stop();
    public int getState();
    public String printName();
    public String printStatus();
}
