/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adrian
 */
public class AppConfig {

    private static final Logger logger = Logger.getLogger(AppConfig.class.getName());

    private Properties m_propsconfig;
    private File configfile;
    private File filename;

    public AppConfig(String[] args) {
        if (args.length == 0) {
            init(getDefaultConfig());
        } else {
            init(new File(args[0]));
        }
    }

    public AppConfig(File configfile) {
        init(configfile);
    }

    private void init(File configfile) {
        this.configfile = configfile;
        m_propsconfig = new Properties();

        String dirname = System.getProperty("dirname.path");
        filename = new File(dirname == null ? "./" : dirname);
    }

    public File getFileName() {
        return filename;
    }

    private File getDefaultConfig() {
        return new File(filename, "openbravohw.properties");
    }

    public String getProperty(String sKey) {
        return m_propsconfig.getProperty(sKey);
    }

    public void load() {

        loadDefault();

        try {
            logger.log(Level.INFO, "Reading configuration file: {0}", configfile.getAbsolutePath());
            InputStream in = new FileInputStream(configfile);
            if (in != null) {
                m_propsconfig.load(in);
                in.close();
            }
        } catch (IOException e){
            logger.log(Level.INFO, "Cannot read configuration file: {0}. Loading defaults.", configfile.getAbsolutePath());
            loadDefault();
        }
    }

    public void loadDefault() {

        m_propsconfig = new Properties();

        m_propsconfig.setProperty("application.version", "0.0.0");

        m_propsconfig.setProperty("server.application", "jetty"); // or tjws
        m_propsconfig.setProperty("server.port", "8090");
        m_propsconfig.setProperty("server.token", "");

        m_propsconfig.setProperty("machine.printer", "usb");
        m_propsconfig.setProperty("machine.printer.2", "");
        m_propsconfig.setProperty("machine.printer.3", "");
        m_propsconfig.setProperty("machine.display", "usb");
        m_propsconfig.setProperty("machine.scale", "screen");

        m_propsconfig.setProperty("images.folder", new File(filename, "img").getPath());

        // Receipt printer paper set to 72mmx200mm
        m_propsconfig.setProperty("paper.receipt.x", "10");
        m_propsconfig.setProperty("paper.receipt.y", "287");
        m_propsconfig.setProperty("paper.receipt.width", "190");
        m_propsconfig.setProperty("paper.receipt.height", "546");
        m_propsconfig.setProperty("paper.receipt.mediasizename", "A4");
        m_propsconfig.setProperty("paper.receipt.fontName", "Monospaced");
        m_propsconfig.setProperty("paper.receipt.fontSize", "7");
        m_propsconfig.setProperty("paper.receipt.fontWidth", "1.0");
        m_propsconfig.setProperty("paper.receipt.fontHeight", "1.4");        
        m_propsconfig.setProperty("paper.receipt.fontLength", "0.0");         
        m_propsconfig.setProperty("paper.receipt.lineHeight", "12");
        m_propsconfig.setProperty("paper.receipt.imageScale", "0.65");

        // Normal printer paper for A4
        m_propsconfig.setProperty("paper.standard.x", "72");
        m_propsconfig.setProperty("paper.standard.y", "72");
        m_propsconfig.setProperty("paper.standard.width", "451");
        m_propsconfig.setProperty("paper.standard.height", "698");
        m_propsconfig.setProperty("paper.standard.mediasizename", "A4");
        m_propsconfig.setProperty("paper.standard.fontName", "Monospaced");
        m_propsconfig.setProperty("paper.standard.fontSize", "7");
        m_propsconfig.setProperty("paper.standard.fontWidth", "1.0");
        m_propsconfig.setProperty("paper.standard.fontHeight", "1.4");         
        m_propsconfig.setProperty("paper.standard.fontLength", "0.0");         
        m_propsconfig.setProperty("paper.standard.lineHeight", "12");
        m_propsconfig.setProperty("paper.standard.imageScale", "0.65");

        m_propsconfig.setProperty("payment.gateway", "external");
        m_propsconfig.setProperty("payment.magcardreader", "Not defined");
        m_propsconfig.setProperty("payment.testmode", "false");
        m_propsconfig.setProperty("payment.commerceid", "");
        m_propsconfig.setProperty("payment.commercepassword", "password");
            
        m_propsconfig.setProperty("machine.payment", "usb");
        
        // Interfaz
        m_propsconfig.setProperty("application.ui", "true"); // true shows a ui, false is a console app
    }

    public String getText() {
        StringBuilder s = new StringBuilder();
        s.append("File: ");
        s.append(configfile.getAbsolutePath());
        s.append("\n");

        s.append("\n## Version ##\n");
        printProperty(s, "application.version");

        s.append("\n## Web server ##\n");
        printProperty(s, "server.application"); // or tjws
        printProperty(s, "server.port");
        printProperty(s, "server.token");

        s.append("\n## Interface ##\n");
        printProperty(s, "application.ui");
        
        s.append("\n## Receipt printers ##\n");
        printProperty(s, "machine.printer");
        printProperty(s, "machine.printer.2");
        printProperty(s, "machine.printer.3");

        s.append("\n## Receipt printer images ##\n");
        printProperty(s, "images.folder");

        s.append("\n## Receipt printer paper ##\n");
        printProperty(s, "paper.receipt.x");
        printProperty(s, "paper.receipt.y");
        printProperty(s, "paper.receipt.width");
        printProperty(s, "paper.receipt.height");
        printProperty(s, "paper.receipt.mediasizename");
        printProperty(s, "paper.receipt.fontName");
        printProperty(s, "paper.receipt.fontSize");
        printProperty(s, "paper.receipt.fontWidth");
        printProperty(s, "paper.receipt.fontHeight");        
        printProperty(s, "paper.receipt.fontLength");        
        printProperty(s, "paper.receipt.lineHeight");
        printProperty(s, "paper.receipt.imageScale");

        s.append("\n## Standard printer paper ##\n");
        printProperty(s, "paper.standard.x");
        printProperty(s, "paper.standard.y");
        printProperty(s, "paper.standard.width");
        printProperty(s, "paper.standard.height");
        printProperty(s, "paper.standard.mediasizename");
        printProperty(s, "paper.standard.fontName");
        printProperty(s, "paper.standard.fontSize");
        printProperty(s, "paper.standard.fontWidth");
        printProperty(s, "paper.standard.fontHeight"); 
        printProperty(s, "paper.standard.fontLength");        
        printProperty(s, "paper.standard.lineHeight");
        printProperty(s, "paper.standard.imageScale");

        s.append("\n## Customer display ##\n");
        printProperty(s, "machine.display");

        s.append("\n## Fiscal printers ##\n");
        printProperty(s, "machine.fiscalprinter");
        printProperty(s, "machine.fiscalprinter.2");
        printProperty(s, "machine.fiscalprinter.3");

        s.append("\n## Scale ##\n");
        printProperty(s, "machine.scale");

        s.append("\n## Payment ##\n");
        printProperty(s, "machine.payment");
        
//        printProperty(s, "payment.gateway", "external");
//        printProperty(s, "payment.magcardreader", "Not defined");
//        printProperty(s, "payment.testmode", "false");
//        printProperty(s, "payment.commerceid", "");
//        printProperty(s, "payment.commercepassword", "password");

        return s.toString();
    }

    public void printProperty(StringBuilder s, String prop) {
        s.append(prop);
        s.append(" = ");
        s.append(m_propsconfig.getProperty(prop, ""));
        s.append("\n");
    }
}
