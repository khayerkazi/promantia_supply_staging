/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.pos.printer.TicketParser;
import com.openbravo.pos.printer.TicketPrinterException;
import com.openbravo.pos.util.StringUtils;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author adrian
 */
public class TicketServlet extends CORSHttpServlet {

    private final TicketParser dtp;

    public TicketServlet(TicketParser dtp) {
        this.dtp = dtp;
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response, request.getParameter("content"));
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response, StringUtils.readReader(request.getReader()));
    }

    private void doProcess(HttpServletRequest request, HttpServletResponse response, String s) throws ServletException, IOException {

        setCORSHeaders(request, response);
        response.setContentType("application/json");

        try {
            dtp.printTicket(s);
            JSONObject o = new JSONObject();
            try {
                o.put("result", "OK");
                o.put("resultData", dtp.getResultData());
            } catch (JSONException ex) {
            }

            response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), o));
        } catch (TicketPrinterException ex) {
            Logger.getLogger(TicketServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.getWriter().println(JSONUtils.getExceptionJSONP(request.getParameter("callback"), ex));
        }
    }
}
