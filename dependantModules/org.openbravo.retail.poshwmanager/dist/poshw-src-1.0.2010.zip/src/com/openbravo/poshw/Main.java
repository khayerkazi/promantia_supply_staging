/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.logging.AuditHandler;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adrian
 */
public class Main {
    
    public static final String AUDITLOGGER = "AuditLogger";    
    
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        
        // counfigure Logger auditlogger
        Logger audit = Logger.getLogger(AUDITLOGGER);
        try {
            audit.setUseParentHandlers(false);
            audit.addHandler(new AuditHandler());
        } catch (IOException ex) {
            logger.log(Level.WARNING, "Cannot initialize AuditLogger.", ex);
        }

        // load main app
        final MainApp app = new MainApp(args);
        
        if (Boolean.parseBoolean(app.getConfig().getProperty("application.ui"))) {
            // App with UI
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new MainFrame(app).init();
                }
            });
        } else {
            // App without UI
            new MainConsole(app).init();
        }
    }
}
