/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.print.PrintService;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.OrientationRequested;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPrintServiceExporter;
import net.sf.jasperreports.engine.export.JRPrintServiceExporterParameter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.DeviceTicket;
import com.openbravo.pos.printjrxml.JRJsonDatasource;
import com.openbravo.pos.printjrxml.JsonProvider;
import com.openbravo.pos.printjrxml.JsonProviderFactory;
import com.openbravo.pos.util.ReportUtils;

/**
 * @author openbravo
 * 
 */
public class TicketPdfServlet extends CORSHttpServlet {

  private AppConfig config;
  private DeviceTicket deviceTicket;

  private static Logger logger = Logger.getLogger(TicketPdfServlet.class.getName());

  // Order Header parameters
  // HashMap<String, Object> parameters = new HashMap<String, Object>();

  String dateFormat = null;
  StringBuffer text = new StringBuffer();

  public TicketPdfServlet(AppConfig config, DeviceTicket deviceTicket) {
    this.config = config;
    this.deviceTicket = deviceTicket;
  }

  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    doProcess(request, response, new StringReader(request.getParameter("content")));
  }

  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    doProcess(request, response, request.getReader());
  }

  private void doProcess(HttpServletRequest request, HttpServletResponse response, Reader r)
      throws ServletException, IOException {

    setCORSHeaders(request, response);
    response.setContentType("application/json");

    try {
      // Retrieve params
      String content = getRequestContent(request.getReader());
      final JSONObject jsonsent = (JSONObject) getContentAsJSON(content);

      // Initialize parameters
      HashMap<String, Object> parameters = new HashMap<String, Object>();

      // Get the order
      JSONObject jsonparam = jsonsent.getJSONObject("param");
      setParameters(jsonparam, null, null, parameters);

      // Set the Image Logo

      File file = new File(config.getProperty("images.folder"));
      String imgPath = file.getAbsolutePath() + System.getProperty("file.separator");
      parameters.put("REPORT_IMG_FOLDER", imgPath);

      // Get the Main report
      JSONObject mainReport = jsonsent.getJSONObject("mainReport");
      final String printer = mainReport.getString("printer");
      final String mainReportData = mainReport.getString("resourcedata");
      dateFormat = mainReport.getString("dateFormat");

      // Set all the parameters as fields in order to be able to display the detail band

      final List<HashMap<String, Object>> parametersHashMapList = new ArrayList<HashMap<String, Object>>();
      parametersHashMapList.add(parameters);

      InputStream is = new ByteArrayInputStream(mainReportData.getBytes("UTF-8"));
      
      // Generate UUID
      UUID uuid = UUID.randomUUID();
      
      // Create a folder for compiled subreports inside system temporary folder with a UUID as name 
      File tmpDir = new File(System.getProperty("java.io.tmpdir"));
      File tempDirUUID = new File(tmpDir, uuid.toString());
      
      if (!tempDirUUID.exists()) {
    	  boolean result = tempDirUUID.mkdir();
    	  if (!result) {
    		  JSONObject o = new JSONObject();
    	        o.put("result", "Subreport Temporary files not created");
    	        response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), o));
    	        return;
    	  }
      }
      
      String subrepPath = tempDirUUID.getAbsolutePath() + System.getProperty("file.separator");
      parameters.put("SUBREPORTS_FOLDER", subrepPath);
      

      // Get the subreports, compile them and generate the compiled file to use in the main report
      JSONArray arraySubReports = jsonsent.getJSONArray("subReports");
      for (int i = 0; i < arraySubReports.length(); i++) {
        JSONObject value = arraySubReports.getJSONObject(i);
        String subReportPath = value.getString("resource");
        String subReportCompiled = subrepPath + subReportPath.substring(subReportPath.lastIndexOf("/") + 1,
            subReportPath.lastIndexOf(".jrxml")) + ".jasper";
        final String subReportData = value.getString("resourcedata");
        InputStream isSubReport = new ByteArrayInputStream(subReportData.getBytes("UTF-8"));
        JasperDesign jasperDesignSubReport = JRXmlLoader.load(isSubReport);
        JasperCompileManager.compileReportToFile(jasperDesignSubReport, subReportCompiled);
      }

      JsonProvider[] parametersList = JsonProviderFactory
          .setObjectToJsonProviderArray(parametersHashMapList);

      // Compile the main report
      JasperReport report = JasperCompileManager.compileReport(is);
      JasperPrint print = JasperFillManager.fillReport(report, parameters, new JRJsonDatasource(
          parametersList, dateFormat));

      // Delete the .jasper files
      String entries[] = tempDirUUID.list();
      for(String s: entries){
    	    File currentFile = new File(tempDirUUID, s);
    	    currentFile.delete();
      }
      if(tempDirUUID.list().length==0){
    	  tempDirUUID.delete();
      }

      // Retrieve the printer
      int printerType = deviceTicket.getDevicePrinter(printer).getPrinterType();
      if (printerType == 2) {
   
        String sprinterName = deviceTicket.getDevicePrinter(printer).getSystemName();

        PrintService selectedPrinter = ReportUtils.getPrintService(sprinterName);

        PrintRequestAttributeSet printRequestAttributeSet = new HashPrintRequestAttributeSet();
        printRequestAttributeSet.add(MediaSizeName.ISO_A4);
        printRequestAttributeSet.add(OrientationRequested.PORTRAIT);
        printRequestAttributeSet.add(new Copies(1));
        JRPrintServiceExporter exporter;
        exporter = new JRPrintServiceExporter();
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
        /* We set the selected service and pass it as a parameter */
        exporter.setParameter(JRPrintServiceExporterParameter.PRINT_SERVICE, selectedPrinter);
        exporter.setParameter(JRPrintServiceExporterParameter.PRINT_SERVICE_ATTRIBUTE_SET,
            selectedPrinter.getAttributes());
        exporter.setParameter(JRPrintServiceExporterParameter.PRINT_REQUEST_ATTRIBUTE_SET,
            printRequestAttributeSet);
        exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PAGE_DIALOG, Boolean.FALSE);
        exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PRINT_DIALOG, Boolean.FALSE);
        exporter.exportReport();
      } else {
        JSONObject o = new JSONObject();
        o.put("result", "Error: The selected printer type is not correct, it should be 'printer'");
        response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), o));
        return;
      }

      JSONObject o = new JSONObject();

      try {
        o.put("result", "OK");
      } catch (JSONException ex) {
      }

      response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), o));
    } catch (Exception ex) {
      logger.log(Level.SEVERE, null, ex);
      response.getWriter().println(
          JSONUtils.getExceptionJSONP(request.getParameter("callback"), ex));
    }
  }

  private String getRequestContent(BufferedReader r) throws IOException {
    if (r == null) {
      return "";
    }
    String line;
    final StringBuilder sb = new StringBuilder();
    while ((line = r.readLine()) != null) {
      if (sb.length() > 0) {
        sb.append("\n");
      }
      sb.append(line);
    }
    return sb.toString();
  }

  protected Object getContentAsJSON(String content) throws JSONException {
    if (content == null || content.equals("")) {
      return new JSONObject();
    } else if (content.trim().startsWith("[")) {
      return new JSONArray(content);
    } else {
      return new JSONObject(content);
    }
  }

  private void setParameters(JSONObject jsonorder, String previousKey,
      HashMap<String, Object> hashmap, HashMap<String, Object> parameters) throws JSONException {

    Iterator<String> keys = jsonorder.keys();
    String key = null;
    while (keys.hasNext()) {
      key = keys.next();
      Object val = null;
      String newKey = key;
      if (previousKey != null) {
        newKey = previousKey + "." + key;
      }
      val = jsonorder.get(key);
      if (val instanceof JSONObject) {
        JSONObject value = jsonorder.getJSONObject(key);
        setParameters(value, newKey, hashmap, parameters);
        createArray(key, value, parameters);
//          if ("taxes".equals(key)) {
//            createTaxesArray(value, parameters);
//          }
      } else if (val instanceof JSONArray) {
        JSONArray array = jsonorder.getJSONArray(key);
        final List<HashMap<String, Object>> hashMapList = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < array.length(); i++) {
          hashmap = new HashMap<String, Object>();
          val = array.get(i);
          if (val instanceof JSONObject) {
            JSONObject value = array.getJSONObject(i);
            setParameters(value, newKey, hashmap, parameters);
            hashMapList.add(hashmap);
          } else if (val instanceof JSONArray) {
            // Arrays inside arrays, not handled yet
          } else {
            // Not Json Objects inside Arrays, not handled yet
          }
        }
        hashmap = null;
        JsonProvider[] list = JsonProviderFactory.setObjectToJsonProviderArray(hashMapList);
        parameters.put("SUBREP_" + key.toUpperCase().replace("$", ""), new JRJsonDatasource(list, dateFormat));
      } else {
        if (hashmap != null) {
          hashmap.put(newKey.toUpperCase().replace("$", ""), val == JSONObject.NULL ? null : val.toString());
        } else {
          parameters.put(newKey.toUpperCase().replace("$", ""), val == JSONObject.NULL ? null : val.toString());
        }
      }
    }
  }

  /**
   * Some objects are a JSONObject when they need to be an array, needs to be converted into an array in order to create a
   * subreport
   * 
   * @param value
   */
  private void createArray(String keyName, JSONObject value, HashMap<String, Object> parameters) throws JSONException {
      final List<HashMap<String, Object>> arrayHashMapList = new ArrayList<HashMap<String, Object>>();
      Iterator<String> arrayKeys = value.keys();
      String key = null;
      Object val = null;
      while (arrayKeys.hasNext()) {
        key = arrayKeys.next();
        val = value.get(key);
        if (val instanceof JSONObject) {
        	JSONObject jsonVal = value.getJSONObject(key);
        	HashMap<String, Object> hashmap = new HashMap<String, Object>();
            Iterator<String> arrayPropertiesKeys = jsonVal.keys();
            String arrayKey = null;
            while (arrayPropertiesKeys.hasNext()) {
              arrayKey = arrayPropertiesKeys.next();
              hashmap.put((keyName + "." + arrayKey).toUpperCase().replace("$", ""), jsonVal.get(arrayKey)
                  .toString());
            }
            arrayHashMapList.add(hashmap);
        } else {
        	// Not a JSON Object, there is no need to create a list
        }
      }
      if (arrayHashMapList.size() > 0) {
    	  JsonProvider[] list = JsonProviderFactory.setObjectToJsonProviderArray(arrayHashMapList);
          parameters.put("SUBREP_" + keyName.toUpperCase().replace("$", ""), new JRJsonDatasource(list, dateFormat));
      }
  }
}
