/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.pos.printer.DeviceTicket;
import com.openbravo.pos.printer.TicketParser;
import com.openbravo.poshw.server.ServerManager;
import com.openbravo.poshw.server.ServerManagerJetty;
import com.openbravo.poshw.server.ServerManagerTJWS;
import java.util.logging.Logger;

/**
 *
 * @author adrian
 */
public class MainApp {

    private final static Logger logger = Logger.getLogger(MainApp.class.getName());

    final private AppConfig config;

    final private DeviceTicket deviceticket;
    final private TicketParser printerDocument;

    final private ServerManager server;

    public MainApp(String[] args) {

        // Licence print
        System.out.println(License.LICENSE_TEXT);

        // Load config properties
        config = new AppConfig(args);
        config.load();

        // Initialization of printer.
        deviceticket = new DeviceTicket(config);
        printerDocument = new TicketParser(deviceticket, config);

        // server initialization
        if ("jetty".equals(config.getProperty("server.application"))) {
            server = new ServerManagerJetty();
        } else {
            server = new ServerManagerTJWS();
        }

        server.init(config);
        server.addServlet("/test", new TestServlet());
        server.addServlet("/printer", new TicketServlet(printerDocument));
        server.addServlet("/scale", new ScaleServlet(deviceticket.getDeviceScale()));
        server.addServlet("/payment", new PaymentServlet(deviceticket.getDevicePayment()));
        server.addServlet("/httpproxy", new HttpServiceServlet());
        server.addServlet("/printerpdf", new TicketPdfServlet(config, deviceticket));
    }

    /**
     * @return the config
     */
    public AppConfig getConfig() {
        return config;
    }

    /**
     * @return the printer
     */
    public DeviceTicket getDeviceTicket() {
        return deviceticket;
    }

    /**
     * @return the printerDocument
     */
    public TicketParser getPrinterDocument() {
        return printerDocument;
    }

    /**
     * @return the server
     */
    public ServerManager getServer() {
        return server;
    }
}
