/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;
import java.util.logging.StreamHandler;

public class TextHandler extends StreamHandler {

    public TextHandler(OutputStream out, String encoding, Level level) {

        setLevel(level);
	setFilter(null);
	setFormatter(new SimpleFormatter());
	try {
	    setEncoding(encoding);
	} catch (Exception ex) {
	}
	setOutputStream(out);
    }

    @Override
    public void publish(LogRecord record) {
	super.publish(record);
	flush();
    }

    @Override
    public void close() {
        flush();
        super.close();
    }
}