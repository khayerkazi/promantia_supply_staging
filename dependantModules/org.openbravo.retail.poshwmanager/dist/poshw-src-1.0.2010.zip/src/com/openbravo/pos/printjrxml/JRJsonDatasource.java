package com.openbravo.pos.printjrxml;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class JRJsonDatasource implements JRDataSource {

  private int index = -1;
  private JsonProvider[] jsonProvider = null;
  private static String strDateFormat;

  private static Logger logger = Logger
      .getLogger("com.openbravo.pos.printer.printjrxml.JRJsonDatasource");

  public JRJsonDatasource(JsonProvider[] jsonProvider, String strDateFormat) {
    this.jsonProvider = jsonProvider;
    this.strDateFormat = strDateFormat;
  }

  @Override
  public Object getFieldValue(JRField jrField) throws JRException {
    Object objValue = null;

    if (jrField != null && jsonProvider != null) {
      String value = jsonProvider[index].getField(jrField.getName());
      Class<?> clazz = jrField.getValueClass();

      try {
    	  if (value != null && !value.equals("")) {
    		  if (clazz.equals(java.lang.Boolean.class)) {
    	            objValue = value.equals("Y") ? Boolean.TRUE : Boolean.FALSE;
    	      } else if (clazz.equals(java.lang.Byte.class)) {
    	            objValue = new Byte(value);
    	      } else if (clazz.equals(java.util.Date.class)) {
    	            SimpleDateFormat dateFormat = new SimpleDateFormat(strDateFormat);
    	            try {
    	              objValue = dateFormat.parse(value);
    	            } catch (Exception e) {
    	              throw new JRException("Unable to parse the date", e);
    	            }
    	      } else if (clazz.equals(java.lang.Double.class)) {
    	            objValue = new Double(value);
    	      } else if (clazz.equals(java.lang.Float.class)) {
    	            objValue = new Float(value);
    	      } else if (clazz.equals(java.lang.Integer.class)) {
    	            objValue = new Integer(value);
    	      } else if (clazz.equals(java.math.BigDecimal.class)) {
    	            objValue = new BigDecimal(value);
    	      } else if (clazz.equals(java.lang.String.class)) {
    	            objValue = new String(value);
    	      } else {
    	            objValue = new String(value);
    	      }
    	  } else {
    		  objValue = null;
    	  }
        
      } catch (Exception e) {
        logger.log(Level.WARNING, "Unable to get value for field '" + jrField.getName()
            + "' of class '" + clazz.getName() + "' for value: " + value, e);
      }
    }
    return objValue;
  }

  @Override
  public boolean next() throws JRException {
    boolean hasNext = false;

    if (jsonProvider != null) {
      if (index < jsonProvider.length - 1) {
        index++;
        hasNext = true;
      }
      // else throw new JRException("Unable to get the FieldProvider.");
    }

    return hasNext;
  }
}
