/*
 ************************************************************************************
 * Copyright (C) 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */
package com.openbravo.pos.fiscal;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import com.openbravo.pos.printer.DeviceDisplay;
import com.openbravo.pos.printer.DeviceDisplayBase;
import com.openbravo.pos.printer.DeviceDisplayImpl;
import com.openbravo.pos.printer.DeviceFiscalPrinter;
import com.openbravo.pos.printer.HardwareException;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;

/**
 *
 * @author adrian
 */
public class DeviceFiscalActiveXEltrade implements DeviceFiscalPrinter, DeviceDisplay, DeviceDisplayImpl {
    
    private final static Logger logger = Logger.getLogger("com.openbravo.pos.fiscal.DeviceFiscalActiveXEltrade");
    
    private static final int ELTRADE_NONFISCAL = 1;
    private static final int ELTRADE_FISCAL = 2;    
    private static final int ELTRADE_INVOICE = 3;
    
    private static final String ELTRADE_NORMAL = "CONDENSED";
    private static final String ELTRADE_BOLD = "BOLD";
    private static final String ELTRADE_ITALIC = "ITALIC";
    private static final String ELTRADE_UNDERLINE = "UNDERLINE";
    private static final String ELTRADE_DOUBLEWIDTH = "DBWIDTH";
    private static final String ELTRADE_DOUBLEHEIGHT = "DBSTRIKE";    
    
    private static final int ELTRADE_DTO_PLU = 1;
    private static final int ELTRADE_DTO_SUBTOTAL = 2;
    private static final int ELTRADE_DTO_ABSOLUTE = 3;
    
    private ActiveXComponent activex;
    private Dispatch obj;
    private boolean ready;
    private int pluline;
    
    private String serial;
    private int port;
    private int bauds;
    
    private DeviceDisplayBase displaylines;
    
    public DeviceFiscalActiveXEltrade(String serial, String bauds) throws Exception {
         
         this.serial = serial;
         if ("COM1:".equals(serial.toUpperCase())) {
             this.port = 1;
         } else if ("COM2:".equals(serial.toUpperCase())) {
             this.port = 2;
         } else if ("COM3:".equals(serial.toUpperCase())) {
             this.port = 3;
         } else if ("COM4:".equals(serial.toUpperCase())) {
             this.port = 4;
         } else {
             throw new HardwareException("Serial port must be COM1:, COM2:, COM3: or COM4:.");
         }
         
         if (bauds == null || bauds.equals("")) {
             this.bauds = 115200;
         } else {
             this.bauds = Integer.parseInt(bauds);
         }
         
         try {
            this.activex = new ActiveXComponent("EltradeFPAx.EltradeFprn");
         } catch (UnsatisfiedLinkError e) {
             throw new HardwareException(e);
         }
         
         this.obj = this.activex.getObject();   
         this.ready = false;
         
         displaylines = new DeviceDisplayBase(this);
    }

    public String getFiscalName() {
        return "Eltrade fiscal printer";
    }
    public String getFiscalDescription() {
        return "ActiveX driver on port: " + serial + ", " + Integer.toString(bauds) + ".";
    }
    public JComponent getFiscalComponent() {
        return null;
    }

    public void reset() throws HardwareException {
        // NOP
    }

    public void test() throws HardwareException {
         openPort();
         callMethod("RunPrinterTest");
         closePort();

//        openPort();
//        Dispatch.call(obj, "StartBon", 2, 1, "Cashier 1", 9000000001L, "123456789", "BG123456789", "Company Name", "City", "Address", "MOL", "Receiver");
//        
//        Dispatch.call(obj, "AddLine", " ", "", 1);
//        Dispatch.call(obj, "AddLine", "134567890123456789012345678901234567890", "CONDENSED", 0);
//        Dispatch.call(obj, "AddLine", 1, "", 1);
//        Dispatch.call(obj, "AddLine", "" , "", 1);
//        
//        Dispatch.call(obj, "AddPLU", "1", "PLU number 1", 1.23, 10, 1);
//        Dispatch.call(obj, "AddDiscount", 1, -0.50);
//        Dispatch.call(obj, "AddLine", "" , "", 1);
//        Dispatch.call(obj, "AddPLU", "2", "PLU number 2", 2.34, 20.25, 1);
//        Dispatch.call(obj, "AddLine", "" , "", 1);  
//         
////        Dispatch.call(obj, "AddDiscount", 2, 2.50);
//        Dispatch.call(obj, "AddDiscount", 3, -3.5456);   
//        Dispatch.call(obj, "AddPayment", 1, "CARD", 2, 1);  
//        Dispatch.call(obj, "AddPayment", 2, "CASH", 54.08, 1);  
//        Dispatch.call(obj, "AddPayment", 3, "ADJUSTEMENT", 1, 0);  
//        
//        Dispatch.call(obj, "EndBon");  
//        closePort();           
//
//        openPort();
//        Dispatch.call(obj, "InOutMoney", 12.2 , 1);
//        closePort();
//        openPort();
//        Dispatch.call(obj, "InOutMoney", 15.0 , 2);
//        closePort();
//        openPort();
//        Dispatch.call(obj, "InOutMoney", 12.3 , 3);
//        closePort();
//        openPort();
//        Dispatch.call(obj, "InOutMoney", 12.4 , 4);
//        closePort();
//        openPort();
//        Dispatch.call(obj, "InOutMoney", 12.5 , 5);
//        closePort();

    }
    public void beginReceipt(String type, String cashier) throws HardwareException {
        beginReceipt(type, cashier, "", "", "", "", "");
    }
    
    public void beginReceipt(String type, String cashier, String invNumber, String taxNumber, String vatNumber, String name, String address) throws HardwareException {
        openPort();
        
        // For invoices
        // Invoice number, tax number, vat number, company name, city, address, mrp, receiver
        // Invoice data: 9000000001L, "123456789", "BG123456789", "Company Name", "City", "Address", "MOL", "Receiver")
        // Invoice null data: "", "", "", "", "", "", "", ""
        callMethod("StartBon", parseFiscalType(type), 1, cashier, invNumber, taxNumber, vatNumber, "Company Name", "City", address, "MOL", name);
        pluline = 0;
    }

    public void endReceipt() throws HardwareException {
        // If payments do not cover the total of the receipt this adjusment payment completes the payment allowing to finish the printing sucessfully.
        callMethod("AddPayment", 8, "Adjustment", 1, 0); // 8 is the reserved payment id
        callMethod("EndBon");
        closePort();
    }

    public void printLine(String sproduct, double dprice, double dunits, int taxinfo) throws HardwareException {
        callMethod("AddPLU", ++pluline, sproduct, dprice, dunits, taxinfo);
    }
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo, double discount) throws HardwareException {
        printLine(sproduct, dprice, dunits, taxinfo); // add the line without any discount
        if (discount != 0.0) {
            callMethod("AddDiscount", ELTRADE_DTO_PLU, discount);
        }
    }

    public void printMessage(String style, String smessage) throws HardwareException {      
        callMethod("AddLine", smessage == null || smessage.equals("") ? " " : smessage, parseStyle(style), 1);
    }
    
    public void printDiscount(double discount) throws HardwareException {
        callMethod("AddDiscount", ELTRADE_DTO_SUBTOTAL, discount);
    }
    
    public void printServiceCharge(double amount) throws HardwareException {
        callMethod("AddDiscount", ELTRADE_DTO_ABSOLUTE, amount);
    }
    
    public void printTotal(int paymentId, String paymentName, double amount) throws HardwareException {
        callMethod("AddPayment", paymentId, paymentName, amount, 1);
    }
    
    public void printCashManagement(int paymentId, String paymentName, double amount) throws HardwareException {
         openPort();
         callMethod("InOutMoney", amount , paymentId);
         closePort();
    }
    
    public void printZReport() throws HardwareException {
         openPort();
         callMethod("RunZReport");
         closePort();
    }

    public void printXReport() throws HardwareException {
         openPort();
         callMethod("RunXReport");
         closePort();
    }

    public String getDisplayName() {
        return "Eltrade display connected to fiscal printer";
    }

    public String getDisplayDescription() {
        return "ActiveX driver on port: " + serial + ", " + Integer.toString(bauds) + ".";
    }

    public JComponent getDisplayComponent() {
        return null;
    }

    public void writeVisor(int animation, String sLine1, String sLine2) {       
        displaylines.writeVisor(animation, sLine1, sLine2);
    }
    
    public void writeVisor(String sLine1, String sLine2) {       
        displaylines.writeVisor(sLine1, sLine2);
    }

    public void clearVisor() {
        displaylines.clearVisor();
    }
    
    public void repaintLines() {
        try {
            openPort();
            callMethod("DisplayPrint", displaylines.getLine1(), displaylines.getLine2());        
            closePort();
        } catch (HardwareException ex) {
            logger.log(Level.WARNING, "Display error captured.", ex);
        }
    }
    
    private void openPort() throws HardwareException {
         if (ready) {
             closePort();
         }
         Variant n = Dispatch.call(obj, "Init", port, bauds, 0, 3, 0, "");
         if (n.getInt() > 0) {
             String msg = MessageFormat.format("Init error code: {0}. {1}", n.getInt(), translateError(n.getInt()));
             logger.log(Level.SEVERE, msg);
             Dispatch.call(obj, "Close");
             throw new HardwareException(msg);
         }   
         ready = true;
    }
    
    private String getLastError() {
        return Dispatch.call(obj, "GetLastError", 0).getString();
    }
    
    private void callMethod(String method, Object... attributes) throws HardwareException {
        if (ready) {
            Variant n = Dispatch.call(obj, method, attributes);
            if (n.getInt() > 0) {
                String msg = MessageFormat.format("Error calling \"{0}\". Code: {1}. {2}", method, n.getInt(), translateError(n.getInt()));
                logger.log(Level.SEVERE, msg);
                closePort();
                throw new HardwareException(msg);
            }
        } else {
            logger.log(Level.WARNING, "Port is not ready.");
            throw new HardwareException("Port is not ready.");
        }
    }
    
    private void closePort() {
        Dispatch.call(obj, "Close");
        ready = false;
    }
    
    private int parseFiscalType(String type) {
        if (DeviceFiscalPrinter.TYPE_FISCAL.equals(type)) {       
            return ELTRADE_FISCAL;
        } else if (DeviceFiscalPrinter.TYPE_INVOICE.equals(type)) {
            return ELTRADE_INVOICE;
        } else { // default
            return ELTRADE_NONFISCAL;
        }
    }
    
    private String parseStyle(String style) {
        if (DeviceFiscalPrinter.STYLE_BOLD.equals(style)) {       
            return ELTRADE_BOLD;
        } else if (DeviceFiscalPrinter.STYLE_ITALIC.equals(style)) {
            return ELTRADE_ITALIC;
        } else if (DeviceFiscalPrinter.STYLE_UNDERLINE.equals(style)) {
            return ELTRADE_UNDERLINE;
        } else if (DeviceFiscalPrinter.STYLE_DOUBLEWIDTH.equals(style)) {
            return ELTRADE_DOUBLEWIDTH;
        } else if (DeviceFiscalPrinter.STYLE_DOUBLEHEIGHT.equals(style)) {
            return ELTRADE_DOUBLEHEIGHT;
        } else { // default
            return ELTRADE_NORMAL;
        }           
    }
    
    private String translateError(int code) {
        switch(code) {
            case 1: return "Error by COM port initialization.";
            case 2: return "Error by communication with printer.";
            case 3: return "No connection to printer.";
            case 4: return "Error induced by the printer: " + getLastError();
            case 5: return "Error induced by the driver.";
            case 6: return "Invalid registration key.";
            case 7: return "The command is not supported by the printer";
            case 8: return "Invalid input data.";
            case 100: return getLastError(); //Other error.
            default: return "Unknown error.";         
        } 
    }
}