/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

public class ScaleDialog1 extends ScaleSerial {

    
    /** Creates a new instance of ScaleDialog1 */
    public ScaleDialog1(String param1, String param2) throws ScaleException {
        super(param1, param2);
    }
    
//    public ScaleDialog1(String port) {
//        super(port);
//    }
//    
//    public ScaleDialog1(String port, int bauds, int databits, int stopbits, int parity, int flowcontrol) {
//        super(port, bauds, databits, stopbits, parity, flowcontrol);
//    }
    
    @Override
    public String getScaleName() {
        return "Dialog1 protocol";
    }

    @Override
    protected byte[] getWeightCommand() {
        return new byte[] {0x05};
    }

    @Override
    protected Double parseWeight(byte[] buffer) {
        double partint = 0.0;
        for (int i = 0; i < buffer.length; i++) {
            partint = partint * 10.0 + (buffer[i] - 0x30);
        }
        double weight = partint / 1000.0;
        return new Double(weight < 0.002 ? 0.0 : weight); // ignore scale adjusting
    }

    @Override
    protected boolean isFinal(int b) {
        return b == 0x001E; // RS ASCII
    }

    @Override
    protected boolean isValid(int b) {
        return b > 0x002F && b < 0x003A;
    }
}
