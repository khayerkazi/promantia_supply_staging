/*
 ************************************************************************************
 * Copyright (C) 2012 - 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

import javax.swing.JComponent;

public class DeviceFiscalPrinterNull implements DeviceFiscalPrinter {

    private String desc;

    public DeviceFiscalPrinterNull() {
        this.desc = "";
    }
    public DeviceFiscalPrinterNull(String desc) {
        this.desc = desc;
    }

    public String getFiscalName() {
        return "Null fiscal printer";
    }
    public String getFiscalDescription() {
        return desc;
    }
    public JComponent getFiscalComponent() {
        return null;
    }

    public void reset() throws HardwareException {
    }
    public void test() throws HardwareException {
    }

    public void beginReceipt(String type, String cashier) throws HardwareException {
    }
    public void beginReceipt(String type, String cashier, String invNumber, String taxNumber, String vatNumber, String name, String address) throws HardwareException {
    }
    public void endReceipt() throws HardwareException {
    }
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo) throws HardwareException {
        printLine(sproduct, dprice, dunits, taxinfo, 0.0);
    }
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo, double discount) throws HardwareException {
    }
    public void printMessage(String style, String smessage) throws HardwareException {
    }

    public void printDiscount(double discount) throws HardwareException {
    }
    public void printServiceCharge(double amount) throws HardwareException {
    }
    public void printTotal(int paymentId, String paymentName, double amount) throws HardwareException {
    }

    public void printCashManagement(int paymentId, String paymentName, double amount) throws HardwareException {
    }
    public void printZReport() throws HardwareException {
    }
    public void printXReport() throws HardwareException {
    }
}
