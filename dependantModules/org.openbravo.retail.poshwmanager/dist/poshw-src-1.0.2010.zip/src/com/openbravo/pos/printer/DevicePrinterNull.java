/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

public class DevicePrinterNull implements DevicePrinter {

    private String description;
    
    /** Creates a new instance of DevicePrinterNull */
    public DevicePrinterNull() {
        description = "";
    }

    public DevicePrinterNull(String desc) {
        description = desc;
    }

    public int getPrinterType() {
        return DevicePrinter.TYPE_NONE;
    }
    public String getPrinterName() {
        return "Null printer";
    }    
    public String getPrinterDescription() {
        return description;
    }        
    public javax.swing.JComponent getPrinterComponent() {
        return null;
    }
    public void reset() {
    }
    public String getSystemName() {
    	return "Null Printer";
    }
    
    public void beginReceipt() {
    }
    public void printBarCode(String type, String position, String code) {        
    }    
    public void printImage(java.awt.image.BufferedImage image) {
    }
    public void beginLine(int iTextSize) {
    }   
    public void printText(int iStyle, String sText) {
    }   
    public void endLine() {
    }
    public void endReceipt() {
    }
    public void openDrawer() {
    }

    public String checkDrawerStatus() { 
        return DevicePrinter.DRAWER_NOTAVAILABLE; 
    }
}
