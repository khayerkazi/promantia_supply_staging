/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import com.openbravo.pos.payment.DevicePayment;
import com.openbravo.pos.payment.DevicePaymentScreen;
import com.openbravo.pos.printer.DeviceDisplay;
import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.TicketPrinterException;
import com.openbravo.pos.printer.screen.DeviceDisplayPanel;
import com.openbravo.pos.printer.screen.DevicePrinterPanel;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.usb.UsbDevice;
import javax.usb.UsbDeviceDescriptor;
import javax.usb.UsbException;
import javax.usb.UsbHostManager;
import javax.usb.UsbHub;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author adrian
 */
public class USBDeviceList {
    
    private static final Logger logger = Logger.getLogger(USBDeviceList.class.getName()); 
    
    private static Map<String, USBDeviceID<DevicePrinter>> printerids = null;
    private static Map<String, USBDeviceID<DevicePrinter>> printeridsbykey = null;
    private static Map<String, USBDeviceID<DeviceDisplay>> displayidsbykey = null;
    private static Map<String, USBDeviceID<DevicePayment>> paymentidsbykey = null;
    
    public static USBDeviceID<DevicePrinter> getPrinterUSBID(String devicetype, String devicemodel) {
        
        loadUSBDevices();
        USBDeviceID<DevicePrinter> usbid = printerids.get(devicetype + " " + devicemodel);
        return usbid == null ? USBDeviceID.NULL : usbid;
    }

    public static DevicePrinter discoverDevicePrinter() throws TicketPrinterException {
        
        loadUSBDevices();
        try {
            USBDeviceID<DevicePrinter> id = discoverUSBID(printeridsbykey);
            if (id == null) {
                logger.log(Level.WARNING, "Not found USB printer");
                return new DevicePrinterPanel("Not found USB printer: Screen printer");
            } else {
                return id.createDevice();
            }
        } catch (UsbException ex) {
            logger.log(Level.WARNING, "Not found USB printer", ex);
            return new DevicePrinterPanel("Not found USB printer: Screen printer");
        }
    }
    
    public static DeviceDisplay discoverDeviceDisplay() throws TicketPrinterException {
        
        loadUSBDevices();
        try {
            USBDeviceID<DeviceDisplay> id = discoverUSBID(displayidsbykey);
            if (id == null) {
                logger.log(Level.WARNING, "Not found USB display");
                return new DeviceDisplayPanel("Not found USB display: Screen display");
            } else {
                return id.createDevice();
            }
        } catch (UsbException ex) {
            logger.log(Level.WARNING, "Not found USB display", ex);
            return new DeviceDisplayPanel("Not found USB display: Screen display");
        }
    }
    
    public static DevicePayment discoverDevicePayment() throws TicketPrinterException {
        
        loadUSBDevices();
        try {
            USBDeviceID<DevicePayment> id = discoverUSBID(paymentidsbykey);
            if (id == null) {
                logger.log(Level.WARNING, "Not found USB payment device");
                return new DevicePaymentScreen("Not found USB payment device: Screen Payment Device");
            } else {
                return id.createDevice();
            }
        } catch (UsbException ex) {
            logger.log(Level.WARNING, "Not found USB payment device", ex);
            return new DevicePaymentScreen("Not found USB payment device: Screen Payment Device");
        }
    }
    
    private static void loadUSBDevices() {
        
        // It is already loaded?
        if (printerids != null) {
            return;
        }
        
        // Initialize maps
        printerids = new HashMap<String, USBDeviceID<DevicePrinter>>();
        printeridsbykey = new HashMap<String, USBDeviceID<DevicePrinter>>();
        displayidsbykey = new HashMap<String, USBDeviceID<DeviceDisplay>>();        
        paymentidsbykey = new HashMap<String, USBDeviceID<DevicePayment>>();        

        // Exists the usbdevices.xml file?
        String dirname = System.getProperty("dirname.path");
        File filename = new File(dirname == null ? "./" : dirname, "usbdevices.xml");
        
        if (!filename.exists()) { 
            logger.log(Level.WARNING, "USB devices list file 'usbdevices.xml' not found.");
            return;
        }
        
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            SAXParser sp  = spf.newSAXParser();
            sp.parse(filename, new DefaultHandler() {
                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) {
                    try {
                        if ("printer".equals(qName)) {                 
                            putUSBPrinter(
                                    attributes.getValue("name"),
                                    (short) Integer.parseInt(attributes.getValue("id").substring(0, 4), 16),
                                    (short) Integer.parseInt(attributes.getValue("id").substring(5, 9), 16),
                                    (USBDeviceBuilder<DevicePrinter>) Class.forName(attributes.getValue("classname")).newInstance());
                        } else if ("display".equals(qName)) {
                            putUSBDisplay(
                                    attributes.getValue("name"), 
                                    (short) Integer.parseInt(attributes.getValue("id").substring(0, 4), 16),
                                    (short) Integer.parseInt(attributes.getValue("id").substring(5, 9), 16),
                                    (USBDeviceBuilder<DeviceDisplay>) Class.forName(attributes.getValue("classname")).newInstance());   
                        } else if ("payment".equals(qName)) {
                            putUSBPayment(
                                    attributes.getValue("name"), 
                                    (short) Integer.parseInt(attributes.getValue("id").substring(0, 4), 16),
                                    (short) Integer.parseInt(attributes.getValue("id").substring(5, 9), 16),
                                    (USBDeviceBuilder<DevicePayment>) Class.forName(attributes.getValue("classname")).newInstance());   
                        }                            
                   } catch (NumberFormatException ex) {
                        Logger.getLogger(USBDeviceList.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InstantiationException ex) {
                        Logger.getLogger(USBDeviceList.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IllegalAccessException ex) {
                        Logger.getLogger(USBDeviceList.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(USBDeviceList.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }               
            });
        } catch (ParserConfigurationException ex) {
            logger.log(Level.WARNING, "Cannot load USB devices list file 'usbdevices.xml'", ex);
        } catch (SAXException ex) {
            logger.log(Level.WARNING, "Cannot load USB devices list file 'usbdevices.xml'", ex);
        } catch (IOException ex) {
            logger.log(Level.WARNING, "Cannot load USB devices list file 'usbdevices.xml'", ex);
        }    
    }
   
    private static void putUSBPrinter(String name, short vendor, short product, USBDeviceBuilder<DevicePrinter> builder) {
        USBDeviceID<DevicePrinter> id = new USBDeviceID<DevicePrinter>(name, vendor, product, builder);
        printerids.put(name, id);    
        printeridsbykey.put(id.getKey(), id);
    }
   
    private static void putUSBDisplay(String name, short vendor, short product, USBDeviceBuilder<DeviceDisplay> builder) {
        USBDeviceID<DeviceDisplay> id = new USBDeviceID<DeviceDisplay>(name, vendor, product, builder);  
        displayidsbykey.put(id.getKey(), id);
    }
    
    private static void putUSBPayment(String name, short vendor, short product, USBDeviceBuilder<DevicePayment> builder) {
        USBDeviceID<DevicePayment> id = new USBDeviceID<DevicePayment>(name, vendor, product, builder);  
        paymentidsbykey.put(id.getKey(), id);
    }
    
    private static <T> USBDeviceID<T> discoverUSBID(Map<String, USBDeviceID<T>> idsbykey) throws UsbException {
        return discoverUSBID(UsbHostManager.getUsbServices().getRootUsbHub(), idsbykey);
    }    
    
    private static <T> USBDeviceID<T> discoverUSBID(UsbHub hub, Map<String, USBDeviceID<T>> idsbykey) throws UsbException {

        for (UsbDevice device : (List<UsbDevice>) hub.getAttachedUsbDevices()) {
            UsbDeviceDescriptor desc = device.getUsbDeviceDescriptor();
            USBDeviceID<T> id = idsbykey.get(USBDeviceID.getKeyFor(desc.idVendor(), desc.idProduct()));
            if (id != null) {
                return id;
            }
            if (device.isUsbHub()) {
                id = discoverUSBID((UsbHub) device, idsbykey);
                if (id != null) {
                    return id;
                }
            }
        }
        return null;    
    }     
}
