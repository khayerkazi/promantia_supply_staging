package com.openbravo.pos.printjrxml;

import java.util.Collection;
import java.util.HashMap;

/**
 * @author unai
 * 
 */
public class JsonProviderFactory implements JsonProvider {

  private Object object;
  private HashMap<String, String> properties;

  /**
   * @param obj
   */
  public JsonProviderFactory(Object obj) {
    object = obj;
    if (obj instanceof HashMap) {
      properties = (HashMap<String, String>) obj;
    } else {
      properties = new HashMap<String, String>();
    }
  }

  /*
   * @see com.openbravo.pos.printjrxml.JsonProvider#getField(java.lang.String)
   */
  @Override
  public String getField(String fieldName) {
    String rt = properties.get(fieldName);
    return rt;
  }

  public void setProperty(String name, String value) {
    properties.put(name, value);
  }

  public static JsonProvider getFieldProvider(Object obj) {
    return new JsonProviderFactory(obj);
  }

  public static <T extends Object> JsonProvider[] setObjectToJsonProviderArray(Collection<T> objs) {
    JsonProviderFactory[] rt = new JsonProviderFactory[objs.size()];
    int i = 0;
    for (Object o : objs) {
      rt[i++] = new JsonProviderFactory(o);
    }
    return rt;
  }

}
