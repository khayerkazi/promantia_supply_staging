/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.ticket;

import java.awt.Font;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

public class PrintItemLine implements PrintItem {

    protected Font font;
    protected int fontheight;
    protected float fontlength;
    protected int textsize;
    protected List<StyledText> m_atext;

    /** Creates a new instance of PrinterItemLine */
    public PrintItemLine(int textsize, Font font, int fontheight, float fontlength) {
        this.textsize = textsize;
        this.font = font;
        this.fontheight = fontheight;
        this.fontlength = fontlength;

        m_atext = new ArrayList<StyledText>();
    }

    public void addText(int style, String text) {
        m_atext.add(new StyledText(style, text));
    }

    public void draw(Graphics2D g, int x, int y, int width) {

        MyPrinterState ps = new MyPrinterState(textsize);
        float left = x;
        for (int i = 0; i < m_atext.size(); i++) {
            StyledText t = m_atext.get(i);
            g.setFont(ps.getFont(font, t.style));
            
            if (fontlength == 0.0F) {
                g.drawString(t.text, left, (float) y);
                left += g.getFontMetrics().getStringBounds(t.text, g).getWidth();
            } else {
                for (int j = 0; j < t.text.length(); j++) {
                    g.drawString(t.text.substring(j, j +1), left, (float) y);
                    left += fontlength;
                }
            }
        }
    }

    public int getHeight() {
        return fontheight * MyPrinterState.getLineMult(textsize);
    }

    protected static class StyledText {

        public StyledText(int style, String text) {
            this.style = style;
            this.text = text;
        }
        public int style;
        public String text;
    }
}
