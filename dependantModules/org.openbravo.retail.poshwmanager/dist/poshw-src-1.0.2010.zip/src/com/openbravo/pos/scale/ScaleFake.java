/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

import javax.swing.JComponent;

public class ScaleFake implements DeviceScale {
    
    /** Creates a new instance of ScaleFake */
    public ScaleFake() {
    }
    
    public Double readWeight() throws ScaleException {
        return new Double(Math.random() * 2.0);
    }

    public String getScaleName() {
        return "Simulator";
    }

    public String getScaleDescription() {
        return "Returns random values.";
    }

    public JComponent getScaleComponent() {
        return null;
    }
}
