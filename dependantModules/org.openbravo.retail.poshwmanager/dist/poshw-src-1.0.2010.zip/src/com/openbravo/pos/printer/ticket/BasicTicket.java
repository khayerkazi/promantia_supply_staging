/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.ticket;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class BasicTicket implements PrintItem {

// Screen
//    private static Font BASEFONT = new Font("Monospaced", Font.PLAIN, 12).deriveFont(AffineTransform.getScaleInstance(1.0, 1.40));
//    private static int LINEHEIGHT = 20;
//    private static double IMAGESCALE = 1.0;
// Printer
//    private static Font BASEFONT = new Font("Monospaced", Font.PLAIN, 7).deriveFont(AffineTransform.getScaleInstance(1.0, 1.40));
//    private static int LINEHEIGHT = 12;
//    private static double IMAGESCALE = 0.65;

    private java.util.List<PrintItem> m_aCommands;
    private PrintItemLine pil;
    private int m_iBodyHeight;

    private Font font;
    private int lineHeight;
    private float fontlength;
    private double imageScale;

    /** Creates a new instance of AbstractTicket */
    public BasicTicket(Font font, float fontlength, int lineHeight, double imageScale) {
        m_aCommands = new ArrayList<PrintItem>();
        pil = null;
        m_iBodyHeight = 0;

        this.font = font;
        this.fontlength = fontlength;
        this.lineHeight = lineHeight;
        this.imageScale = imageScale;
    }

    protected Font getBaseFont() {
        return font;
    }
    
    protected float getFontLength() {
        return fontlength;
    }

    protected int getLineHeight() {
        return lineHeight;
    }

    protected double getImageScale() {
        return imageScale;
    }

    public int getHeight() {
        return m_iBodyHeight;
    }

    public void draw(Graphics2D g2d, int x, int y, int width) {

        int currenty = y;
        for (PrintItem pi : m_aCommands) {
            pi.draw(g2d, x, currenty, width);
            currenty += pi.getHeight();
        }
    }

    public java.util.List<PrintItem> getCommands() {
        return m_aCommands;
    }

    // INTERFAZ PRINTER 2
    public void printImage(BufferedImage image) {

        PrintItem pi = new PrintItemImage(image, getImageScale());
        m_aCommands.add(pi);
        m_iBodyHeight += pi.getHeight();
    }

    public void printBarCode(String type, String position, String code) {

        PrintItem pi = new PrintItemBarcode(type, position, code, getImageScale());
        m_aCommands.add(pi);
        m_iBodyHeight += pi.getHeight();
    }

    public void beginLine(int iTextSize) {
        pil = new PrintItemLine(iTextSize, getBaseFont(), getLineHeight(), getFontLength());
    }

    public void printText(int iStyle, String sText) {
        if (pil != null) {
            pil.addText(iStyle, sText);
        }
    }

    public void endLine() {
        if (pil != null) {
            m_aCommands.add(pil);
            m_iBodyHeight += pil.getHeight();
            pil = null;
        }
    }
}
