/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.awt.image.BufferedImage;

import javax.swing.JComponent;

import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.TicketPrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DevicePrinterESCPOS implements DevicePrinter {
       
    private final static Logger logger = Logger.getLogger(DevicePrinterESCPOS.class.getName());

    private final PrinterWritter m_CommOutputPrinter;    
    private final Codes m_codes;
    private final UnicodeTranslator m_trans;
    private final String m_sName;

    // Creates new TicketPrinter
    public DevicePrinterESCPOS(PrinterWritter CommOutputPrinter, Codes codes,
            UnicodeTranslator trans) throws TicketPrinterException {

        m_sName = "Serial printer";
        m_CommOutputPrinter = CommOutputPrinter;
        m_codes = codes;
        m_trans = trans;

        // Inicializamos la impresora
        m_CommOutputPrinter.init(ESCPOS.INIT);

        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER); // A la impresora
        m_CommOutputPrinter.init(m_codes.getInitSequence());
        m_CommOutputPrinter.write(m_trans.getCodeTable());

        m_CommOutputPrinter.flush();
    }
   
    public int getPrinterType() {
        return DevicePrinter.TYPE_NONE;
    }

    public String getPrinterName() {
        return m_sName;
    }

    public String getPrinterDescription() {
        return m_CommOutputPrinter.getDescription() + " " + m_codes.getDescription();
    }

    public JComponent getPrinterComponent() {
        return null;
    }

    public void reset() {
    }

    public String getSystemName() {
        return "";
    }
    
    public void beginReceipt() {
    }

    public void printImage(BufferedImage image) {

        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);
        m_CommOutputPrinter.write(m_codes.transImage(image));
    }

    public void printBarCode(String type, String position, String code) {

        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);
        m_codes.printBarcode(m_CommOutputPrinter, type, position, code);
    }

    public void beginLine(int iTextSize) {

        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);

        if (iTextSize == DevicePrinter.SIZE_0) {
            m_CommOutputPrinter.write(m_codes.getSize0());
        } else if (iTextSize == DevicePrinter.SIZE_1) {
            m_CommOutputPrinter.write(m_codes.getSize1());
        } else if (iTextSize == DevicePrinter.SIZE_2) {
            m_CommOutputPrinter.write(m_codes.getSize2());
        } else if (iTextSize == DevicePrinter.SIZE_3) {
            m_CommOutputPrinter.write(m_codes.getSize3());
        } else {
            m_CommOutputPrinter.write(m_codes.getSize0());
        }
    }

    public void printText(int iStyle, String sText) {

        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);

        if ((iStyle & DevicePrinter.STYLE_BOLD) != 0) {
            m_CommOutputPrinter.write(m_codes.getBoldSet());
        }
        if ((iStyle & DevicePrinter.STYLE_UNDERLINE) != 0) {
            m_CommOutputPrinter.write(m_codes.getUnderlineSet());
        }
        m_CommOutputPrinter.write(m_trans.transString(sText));
        if ((iStyle & DevicePrinter.STYLE_UNDERLINE) != 0) {
            m_CommOutputPrinter.write(m_codes.getUnderlineReset());
        }
        if ((iStyle & DevicePrinter.STYLE_BOLD) != 0) {
            m_CommOutputPrinter.write(m_codes.getBoldReset());
        }
    }

    public void endLine() {
        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);
        m_CommOutputPrinter.write(m_codes.getNewLine());
    }

    public void endReceipt() {
        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);

        m_CommOutputPrinter.write(m_codes.getNewLine());
        m_CommOutputPrinter.write(m_codes.getNewLine());
        m_CommOutputPrinter.write(m_codes.getNewLine());
        m_CommOutputPrinter.write(m_codes.getNewLine());
        m_CommOutputPrinter.write(m_codes.getNewLine());

        m_CommOutputPrinter.write(m_codes.getCutReceipt());
        m_CommOutputPrinter.flush();
    }

    public void openDrawer() {
        m_CommOutputPrinter.write(ESCPOS.SELECT_PRINTER);
        m_CommOutputPrinter.write(m_codes.getOpenDrawer());
        m_CommOutputPrinter.flush();
    }

    public String checkDrawerStatus() {

        synchronized (this) {
            byte[] code = m_codes.getDrawerStatus();
            if (code != null) {
                m_CommOutputPrinter.write(m_codes.getDrawerStatus()); // GS r
                m_CommOutputPrinter.flush();

                try {
                    wait(100);
                } catch (InterruptedException e) {
                    logger.log(Level.SEVERE, null, e);
                }

                switch (m_CommOutputPrinter.read()) {
                    case 0: return DevicePrinter.DRAWER_OPEN;
                    case 1: return DevicePrinter.DRAWER_CLOSED;
                    default: return DevicePrinter.DRAWER_ERROR;
                }
            } else {
                logger.info("Check drawer status not implemented.");
                return DevicePrinter.DRAWER_NOTAVAILABLE;
            }
        }
    }
}
