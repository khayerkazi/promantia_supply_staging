/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.service;

import com.openbravo.pos.payment.DevicePayment;
import com.openbravo.pos.payment.DevicePaymentScreen;
import com.openbravo.pos.printer.escpos.USBDeviceList;

/**
 * 
 * @author adrian
 */
public class BasicPaymentService implements PaymentService {

    @Override
    public DevicePayment getPayment(String type, HardwareConfig hwconfig) throws Exception {
        if ("screen".equals(type)) {
            return new DevicePaymentScreen();
        } else if ("usb".equals(type)) {
            return USBDeviceList.discoverDevicePayment();   
        } else {
            return null;
        }
    }  
}
