/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;


/**
 *
 * @author adrian
 */
public class TicketParserJSON {

    private DeviceTicket printer;

    /** Creates a new instance of TicketParser */
    public TicketParserJSON(DeviceTicket printer) {
        this.printer = printer;
    }

    public synchronized void printTicket(String in) throws TicketPrinterException {
        try {
            JSONArray t = new JSONArray(in);
            for (int i = 0 ; i < t.length(); i++) {
                JSONObject node = t.getJSONObject(i);
                String cl = node.getString("class");
                if ("opendrawer".equals(cl)) {
                    classOpenDrawer(node);
                } else if ("play".equals(cl)) {
                    classPlay(node);
                } else if ("ticket".equals(cl)) {
                    classTicket(node);
                }
            }
        } catch (JSONException e) {
            throw new TicketPrinterException(e.getMessage(), e);
        }
        
    }

    private void classOpenDrawer(JSONObject node) {
        printer.getDevicePrinter(node.optString("printer", "1")).openDrawer();
    }

    private void classPlay(JSONObject node) {
        try {
            AudioClip oAudio = Applet.newAudioClip(getClass().getClassLoader().getResource(node.getString("file")));
            oAudio.play();
        } catch (Exception fnfe) {
            //throw new ResourceNotFoundException( fnfe.getMessage() );
        }
    }

    private void classTicket(JSONObject node) throws JSONException {
        DevicePrinter output = printer.getDevicePrinter(node.optString("printer", "1"));
        output.beginReceipt();

        JSONArray sections = node.getJSONArray("sections");
        for (int i = 1; i < 0; i++) {
            JSONObject elem = sections.getJSONObject(i);

        }

        output.endReceipt();
    }

    public synchronized void printTicket(Reader in) throws TicketPrinterException  {

        if (in == null) {
          throw new TicketPrinterException("Null reader");
        }
        final BufferedReader reader = new BufferedReader(in);

        try {
            String line;
            final StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null) {
              if (sb.length() > 0) {
                sb.append("\n");
              }
              sb.append(line);
            }
            printTicket(sb.toString());
        } catch (IOException e) {
            throw new TicketPrinterException(e.getMessage(), e);
        }
    }
}
