/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.usb.UsbEndpoint;
import javax.usb.UsbException;
import javax.usb.UsbInterface;
import javax.usb.UsbInterfacePolicy;
import javax.usb.UsbPipe;

public class PrinterWritterUSB extends PrinterWritter {
    
    private static final Logger logger = Logger.getLogger(PrinterWritterUSB.class.getName());
    
    private static final int BUFFER_SIZE = 128;
    
    private static final int ENDPOINT_INX_OUT = 0;
    private static final int ENDPOINT_INX_IN = 1;
    
    private final USBDeviceID<?> usbid;
    
    private UsbInterface iface = null;

    public PrinterWritterUSB(USBDeviceID<?> usbid) {
        this.usbid = usbid;
    }
    
    @Override
    public String getDescription() {
        return "USB Device: " + usbid.getName() + ".";
    }

    @Override
    public void write(byte[] data) {
        try {
            // construct iface lazily
            constructInterface();

            // Send data
            logger.log(Level.FINE, "Writing. Begin.");
            UsbEndpoint endpoint = (UsbEndpoint) iface.getUsbEndpoints().get(ENDPOINT_INX_OUT);
            UsbPipe pipe = endpoint.getUsbPipe();
            pipe.open();
            try {
                pipe.syncSubmit(data);
            } finally {
                pipe.close();
            } 
            logger.log(Level.FINE, "Writing. Success.");
        } catch (UsbException ex) {
            close();
            logger.log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int read() {
        try {
            // construct iface lazily
            constructInterface();
            
            // Read data
            logger.log(Level.FINE, "Reading. Begin.");
            UsbEndpoint usbin = (UsbEndpoint) iface.getUsbEndpoints().get(ENDPOINT_INX_IN);
            UsbPipe pipein = usbin.getUsbPipe();
            pipein.open();
            try {
                byte[] data = new byte[BUFFER_SIZE];
                int received = pipein.syncSubmit(data);
                if (received > 0) {
                    logger.log(Level.FINE, "Reading. Success.");
                    // Get the last value in the buffer and discard previous results
                    return (int) data[received - 1];     
                } else {
                    logger.log(Level.FINE, "Reading. No data.");
                    return -1;
                }
            } finally {
                pipein.close();
            }
        } catch (UsbException ex) {
            close();
            logger.log(Level.SEVERE, null, ex);
            return -1;
        }        
    }

    @Override
    public void flush() {
        close();
    }

    @Override
    public void close() {
        if (iface != null) {
            try {
                logger.log(Level.FINE, "Close. Begin.");
                iface.release();
                logger.log(Level.FINE, "Close. Success.");                
            } catch (UsbException ex) {
                logger.log(Level.SEVERE, null, ex);
            } finally {
                iface = null;
            }
        }
    }
    
    private void constructInterface() throws UsbException {

        if (iface == null) {
            try {
                logger.log(Level.FINE, "Constructing USB Interface. Begin.");
                iface = usbid.findInterface();
                if (iface == null) {
                    throw new UsbException("USB Device not found.");
                }
                if (iface.getUsbEndpoints().size() < 2) {
                    throw new UsbException("USB Device end points not found.");
                }
                iface.claim(new UsbInterfacePolicy() {            
                    @Override
                    public boolean forceClaim(UsbInterface usbInterface) {
                        return true;
                    }
                });
                logger.log(Level.FINE, "Constructing USB Interface. Success.");
            } catch (UsbException ex) {
                logger.log(Level.FINE, "Constructing USB Interface. Error.");
                iface = null;
                throw ex;
            }
        }        
    }   
}
