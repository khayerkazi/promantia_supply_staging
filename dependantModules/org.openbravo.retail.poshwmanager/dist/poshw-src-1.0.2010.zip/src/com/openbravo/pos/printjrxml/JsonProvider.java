package com.openbravo.pos.printjrxml;

/**
 * @author unai
 * 
 */
public interface JsonProvider {
  public String getField(String fieldName);
}
