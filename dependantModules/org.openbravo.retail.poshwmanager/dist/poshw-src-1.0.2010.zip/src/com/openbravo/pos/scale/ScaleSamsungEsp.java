/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

public class ScaleSamsungEsp extends ScaleSerial {
        
    /** Creates a new instance of ScaleSamsungEsp */
    public ScaleSamsungEsp(String param1, String param2) throws ScaleException {
        super(param1, param2);
    }
    
//    public ScaleSamsungEsp(String port) {
//        super(port);
//    }
//    
//    public ScaleSamsungEsp(String port, int bauds, int databits, int stopbits, int parity, int flowcontrol) {
//        super(port, bauds, databits, stopbits, parity, flowcontrol);
//    }

    @Override
    public String getScaleName() {
        return "Samsung protocol";
    }

    @Override
    protected byte[] getWeightCommand() {
        return new byte[] {0x24}; // $
    }

    @Override
    protected Double parseWeight(byte[] buffer) {
        double partint = 0.0;
        double partexp = 1.0;
        boolean decimals = false;
        for (int i = 0; i < buffer.length; i++) {
            if (buffer[i] == 0x2E) {
                decimals = true;
            } else {
                partint = partint * 10.0 + (buffer[i] - 0x30);
                if (decimals) {
                    partexp *= 10.0;
                }
            }
        }
        double weight = partint / partexp;
        return new Double(weight < 0.002 ? 0.0 : weight); // ignore scale adjusting
    }

    @Override
    protected boolean isFinal(int b) {
        return b == 0x000D; // CR ASCII
    }

    @Override
    protected boolean isValid(int b) {
        return (b > 0x002F && b < 0x003A) || b == 0x002E;
    }
}
