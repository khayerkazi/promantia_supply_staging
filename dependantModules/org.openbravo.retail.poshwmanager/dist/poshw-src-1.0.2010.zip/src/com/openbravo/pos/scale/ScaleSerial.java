/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

import com.openbravo.pos.util.StringParser;
import gnu.io.*;
import java.io.*;
import java.util.ArrayList;
import java.util.TooManyListenersException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;

public abstract class ScaleSerial implements DeviceScale, SerialPortEventListener {

    private static final Logger logger = Logger.getLogger(ScaleSerial.class.getName());

    protected CommPortIdentifier comport;
    protected SerialPort serialport;

    protected String port;
    protected int bauds;
    protected int databits;
    protected int stopbits;
    protected int parity;
    protected int flowcontrol;    
  
    protected OutputStream out;
    protected InputStream in;

    protected static final int SCALE_READY = 0;
    protected static final int SCALE_READING = 1;
    
    protected byte[] readBytes;

    protected int status;
    protected ArrayList<Integer> buffer = new ArrayList<Integer>();
    
    public ScaleSerial(String param1, String param2) throws ScaleException {
        
        if ("serial".equals(param1) || "rxtx".equals(param1)) {
            StringParser p = new StringParser(param2);
            this.port = p.nextToken(',');
            this.bauds = parseInt(p.nextToken(','), 4800);
            this.databits = parseInt(p.nextToken(','), SerialPort.DATABITS_8);
            this.stopbits = parseInt(p.nextToken(','), SerialPort.STOPBITS_1);
            this.parity = parseInt(p.nextToken(','), SerialPort.PARITY_NONE);
            this.flowcontrol = parseInt(p.nextToken(','), SerialPort.FLOWCONTROL_NONE);
            
            out = null;
            in = null;

            status = SCALE_READY;
            buffer.clear();            
        } else {
            throw new ScaleException();
        }
    }

    /** Creates a new instance of ScaleSerial */
    public ScaleSerial(String port) {
        this(port, 4800, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_ODD, SerialPort.FLOWCONTROL_NONE);
    }
    
    public ScaleSerial(String port, int bauds, int databits, int stopbits, int parity, int flowcontrol) {
        this.port = port;
        this.bauds = bauds; // Default 4800
        this.databits = databits; // Default 8
        this.stopbits = stopbits; // Default 1
        this.parity = parity; // Default 1: ODD
        this.flowcontrol = flowcontrol; // Default 0: NONE    
        out = null;
        in = null;

        status = SCALE_READY;
        buffer.clear();        
    }
 
    public final String getScaleDescription() {
        return "Connected to port \"" + port + "\".";
    }

    protected abstract byte[] getWeightCommand();

    protected abstract Double parseWeight(byte[] buffer) throws ScaleException;

    protected abstract boolean isFinal(int b);

    protected abstract boolean isValid(int b);

    public Double readWeight() throws ScaleException {

        synchronized(this) {

            if (status != SCALE_READY) {
                try {
                    wait(1000);
                } catch (InterruptedException e) {
                }
                if (status != SCALE_READY) {
                    // wrong status.
                    status = SCALE_READY;
                }
            }

            // Ready
            buffer.clear();
            write(getWeightCommand());
            flush();

            // Wait for one second
            try {
                wait(1000);
            } catch (InterruptedException e) {
            }

            if (status == SCALE_READY) {
                // parse buffer
                Double d = parseWeight(convertBuffer());
                buffer.clear();
                return d;
            } else {
                status = SCALE_READY;
                return new Double(0.0);
            }
        }
    }


    public final JComponent getScaleComponent() {
        return null;
    }

    private void flush() {
        try {
            out.flush();
        } catch (IOException e) {
        }
    }

    private void write(byte[] data) {
        try {
            if (out == null) {
                comport = CommPortIdentifier.getPortIdentifier(port); // Tomamos el puerto
                serialport = (SerialPort) comport.open("PORTID", 2000); // Abrimos el puerto

                out = serialport.getOutputStream(); // Tomamos el chorro de escritura
                in = serialport.getInputStream();

                serialport.addEventListener(this);
                serialport.notifyOnDataAvailable(true);

                serialport.setSerialPortParams(bauds, databits, stopbits, parity);
                serialport.setFlowControlMode(flowcontrol);
            }
            out.write(data);
        } catch (NoSuchPortException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (PortInUseException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (UnsupportedCommOperationException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (TooManyListenersException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (IOException e) {
            logger.log(Level.SEVERE, null, e);
        }
    }

    public void serialEvent(SerialPortEvent e) {

	// Determine type of event.
	switch (e.getEventType()) {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
            case SerialPortEvent.DATA_AVAILABLE:
                try {
                    while (in.available() > 0) {
                        int b = in.read();
                        if (isFinal(b)) { // CR ASCII
                            synchronized (this) {
                                status = SCALE_READY;
                                notifyAll();
                            }
                        } else if (isValid(b)){
                            synchronized(this) {
                                if (status == SCALE_READY) {
                                    buffer.add(b);
                                    status = SCALE_READING;
                                }
                            }
                        } else {
                            // invalid character
                            synchronized(this) {
                                buffer.clear();
                                status = SCALE_READY;
                            }
                        }
                    }

                } catch (IOException eIO) {
                    logger.log(Level.SEVERE, null, eIO);
                }
                break;
        }
    }

    protected byte[] convertBuffer() {

        byte[] ret = new byte[buffer.size()];
        for(int i = 0; i < ret.length; i++) {
            ret[i] = buffer.get(i).byteValue();
        }
        return ret;
    }
    
    private static int parseInt(String sValue, int iDefault) {
        try {
            return Integer.parseInt(sValue);
        } catch (NumberFormatException eNF) {
            return iDefault;
        }
    }    
}
