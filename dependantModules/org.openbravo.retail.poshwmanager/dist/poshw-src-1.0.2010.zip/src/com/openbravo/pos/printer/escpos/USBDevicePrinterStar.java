/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.TicketPrinterException;

/**
 *
 * @author adrian
 */
public class USBDevicePrinterStar implements USBDeviceBuilder<DevicePrinter> {
    @Override public DevicePrinter build(USBDeviceID<DevicePrinter> id) throws TicketPrinterException {
        return new DevicePrinterESCPOS(new PrinterWritterUSB(id), new CodesStar(), new UnicodeTranslatorStar()); 
    }
}