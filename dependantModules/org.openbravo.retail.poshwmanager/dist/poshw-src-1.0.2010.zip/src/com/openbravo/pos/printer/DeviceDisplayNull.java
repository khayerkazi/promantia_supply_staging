/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

public class DeviceDisplayNull implements DeviceDisplay {
    
    private String description;
    
    /** Creates a new instance of DeviceDisplayNull */
    public DeviceDisplayNull() {
        this("");
    }

    /** Creates a new instance of DeviceDisplayNull */
    public DeviceDisplayNull(String desc) {
        description = desc;
    }

    public String getDisplayName() {
        return "Null display";
    }    
    public String getDisplayDescription() {
        return description;
    }        
    public javax.swing.JComponent getDisplayComponent() {
        return null;
    }
    
    public void clearVisor() {
    }      
    public void writeVisor(String sLine1, String sLine2) {
    } 
    public void writeVisor(int animation, String sLine1, String sLine2) {
    } 
}
