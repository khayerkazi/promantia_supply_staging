/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

import javax.swing.JComponent;

public class ScaleNull implements DeviceScale {

    private String description;

    /** Creates a new instance of ScaleNull */
    public ScaleNull() {
        description = "";
    }

    public ScaleNull(String desc) {
        description = desc;
    }

    public Double readWeight() throws ScaleException {
        throw new ScaleException("Scale not defined.");
    }

    public String getScaleName() {
        return "Null Scale";
    }

    public String getScaleDescription() {
        return description;
    }

    public JComponent getScaleComponent() {
        return null;
    }
}
