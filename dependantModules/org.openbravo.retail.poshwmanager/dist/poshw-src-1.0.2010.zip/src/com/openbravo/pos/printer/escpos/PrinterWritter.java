/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

public abstract class PrinterWritter {

    private boolean initialized = false;

    public PrinterWritter() {
    }

    public abstract String getDescription();

    public abstract void write(byte[] data);
    public abstract int read();
    public abstract void flush();
    public abstract void close();
    
    public void init(final byte[] data) {
        if (!initialized) {
            write(data);
            initialized = true;
        }
    }

    public void write(String sValue) {
        write(sValue.getBytes());
    }

    public void write(byte b) {
        write(new byte[] { b });
    }
}
