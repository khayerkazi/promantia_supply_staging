/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */
package com.openbravo.pos.printer.escpos;

import com.openbravo.pos.printer.TicketPrinterException;
import java.util.List;
import java.util.logging.Logger;
import javax.usb.UsbConfiguration;
import javax.usb.UsbDevice;
import javax.usb.UsbDeviceDescriptor;
import javax.usb.UsbException;
import javax.usb.UsbHostManager;
import javax.usb.UsbHub;
import javax.usb.UsbInterface;

/**
 *
 * @author adrian
 * @param <T>
 */
public class USBDeviceID<T> {
    
    public static final USBDeviceID NULL = new USBDeviceID("", (short)0x0000, (short)0x0000, null);
    
    private static final Logger logger = Logger.getLogger(USBDeviceID.class.getName());    
    
    private final String name;
    private final short vendor;
    private final short product;
    private final USBDeviceBuilder<T> builder;

    public USBDeviceID(String name, short vendor, short product, USBDeviceBuilder<T> builder) {
        this.name = name;
        this.vendor = vendor;
        this.product = product;
        this.builder = builder;
    }

    public String getName() {
        return name;
    }

    public String getKey() {
        return getKeyFor(vendor, product);
    }

    public short getVendor() {
        return vendor;
    }

    public short getProduct() {
        return product;
    }
    
    public T createDevice() throws TicketPrinterException {
        return (builder == null) ? null : builder.build(this);
    } 

    public UsbInterface findInterface() throws UsbException {

        if (this == USBDeviceID.NULL) {
            logger.warning("Device type and model not supported by Openbravo.");
            return null;
        }

        UsbDevice device = findDevice(UsbHostManager.getUsbServices().getRootUsbHub());
        if (device == null) {
            logger.warning("Device not connected to computer.");
            return null; // Device not connected to computer.
        }
        UsbConfiguration configuration = device.getActiveUsbConfiguration();
        return configuration.getUsbInterface((byte) 0x00);
    }

    private UsbDevice findDevice(UsbHub hub) throws UsbException {
        for (UsbDevice device : (List<UsbDevice>) hub.getAttachedUsbDevices()) {
            UsbDeviceDescriptor desc = device.getUsbDeviceDescriptor();
            if (desc.idVendor() == vendor && desc.idProduct() == product) {
                return device;
            }
            if (device.isUsbHub()) {
                device = findDevice((UsbHub) device);
                if (device != null) {
                    return device;
                }
            }
        }
        return null;
    }
    
    public static String getKeyFor(short vendor, short product) {
        return Short.toString(vendor) + ":" + Short.toString(product);
    }    
}
