/*
 ************************************************************************************
 * Copyright (C) 2012 - 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.service;

import com.openbravo.pos.printer.DeviceDisplay;
import com.openbravo.pos.printer.DeviceFiscalPrinter;
import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.scale.DeviceScale;

/**
 *
 * @author adrian
 */
public interface HardwareService {

    public DeviceDisplay getDisplay(String type, HardwareConfig hwconfig) throws Exception;
    public DevicePrinter getPrinter(String type, HardwareConfig hwconfig) throws Exception;
    public DeviceScale getScale(String type, HardwareConfig hwconfig) throws Exception;
    public DeviceFiscalPrinter getFiscal(String type, HardwareConfig hwconfig) throws Exception;
}
