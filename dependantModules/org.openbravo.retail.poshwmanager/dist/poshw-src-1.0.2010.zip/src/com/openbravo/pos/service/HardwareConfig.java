/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.service;

import com.openbravo.pos.printer.TicketPrinterException;
import com.openbravo.pos.printer.escpos.PrinterWritter;

/**
 *
 * @author adrian
 */
public interface HardwareConfig {

    public String getDeviceType();
    public String getParameter1();
    public String getParameter2();
    public String getConfigProperty(String prop);
    public PrinterWritter createPrinterWritter() throws TicketPrinterException;
}
