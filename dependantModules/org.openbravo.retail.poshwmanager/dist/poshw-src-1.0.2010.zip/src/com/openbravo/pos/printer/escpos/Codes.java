/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.DeviceTicket;
import java.awt.image.BufferedImage;

public abstract class Codes {

    /** Creates a new instance of Codes */
    public Codes() {
    }

    public abstract String getDescription();

    public abstract byte[] getInitSequence();
    
    public abstract byte[] getSize0();
    public abstract byte[] getSize1();
    public abstract byte[] getSize2();
    public abstract byte[] getSize3();

    public abstract byte[] getBoldSet();
    public abstract byte[] getBoldReset();
    public abstract byte[] getUnderlineSet();
    public abstract byte[] getUnderlineReset();
    
    public abstract byte[] getOpenDrawer(); 
    public byte[] getDrawerStatus() {
        return null;
    }
    public abstract byte[] getCutReceipt();   
    public abstract byte[] getNewLine();    
    public abstract byte[] getImageHeader();
    public abstract int getImageWidth();

    public static byte[] transCode128(String sCad) {

        if (sCad == null) {
            return null;
        } else {
            byte bAux[] = new byte[sCad.length()];
            for( int i = 0; i < sCad.length(); i++) {
                bAux[i] = Codes.transCode128Char(sCad.charAt(i));
            }
            return bAux;
        }
    }

    public static byte transCode128Char(char sChar) {
        switch (sChar) {
        case '/' : return 0x2F;
        case '0' : return 0x30;
        case '1' : return 0x31;
        case '2' : return 0x32;
        case '3' : return 0x33;
        case '4' : return 0x34;
        case '5' : return 0x35;
        case '6' : return 0x36;
        case '7' : return 0x37;
        case '8' : return 0x38;
        case '9' : return 0x39;
        case 'A' : return 0x41;
        case 'B' : return 0x42;
        case 'C' : return 0x43;
        case 'D' : return 0x44;
        case 'E' : return 0x45;
        case 'F' : return 0x46;
        case 'G' : return 0x47;
        case 'H' : return 0x48;
        case 'I' : return 0x49;
        case 'J' : return 0x4A;
        case 'K' : return 0x4B;
        case 'L' : return 0x4C;
        case 'M' : return 0x4D;
        case 'N' : return 0x4E;
        case 'O' : return 0x4F;
        case 'P' : return 0x50;
        case 'Q' : return 0x51;
        case 'R' : return 0x52;
        case 'S' : return 0x53;
        case 'T' : return 0x54;
        case 'U' : return 0x55;
        case 'V' : return 0x56;
        case 'W' : return 0x57;
        case 'X' : return 0x58;
        case 'Y' : return 0x59;
        case 'Z' : return 0x5A;
        case '[' : return 0x5B;
        case '\\' : return 0x5C;
        case ']' : return 0x5D;
        case '^' : return 0x5E;
        case '_' : return 0x5F;
        case '\'' : return 0x60;
        case 'a' : return 0x61;
        case 'b' : return 0x62;
        case 'c' : return 0x63;
        case 'd' : return 0x64;
        case 'e' : return 0x65;
        case 'f' : return 0x66;
        case 'g' : return 0x67;
        case 'h' : return 0x68;
        case 'i' : return 0x69;
        case 'j' : return 0x6A;
        case 'k' : return 0x6B;
        case 'l' : return 0x6C;
        case 'm' : return 0x6D;
        case 'n' : return 0x6E;
        case 'o' : return 0x6F;
        case 'p' : return 0x70;
        case 'q' : return 0x71;
        case 'r' : return 0x72;
        case 's' : return 0x73;
        case 't' : return 0x74;
        case 'u' : return 0x75;
        case 'v' : return 0x76;
        case 'w' : return 0x77;
        case 'x' : return 0x78;
        case 'y' : return 0x79;
        case 'z' : return 0x7A;
        case '{' : return 0x7B;
        case '|' : return 0x7C;
        case '}' : return 0x7D;
        case '~' : return 0x7E;
        default: return 0x30;
        }
    }

    public void printBarcode(PrinterWritter out, String type, String position, String code) {

        if (DevicePrinter.BARCODE_EAN13.equals(type)) {

            out.write(getNewLine());

            out.write(ESCPOS.BAR_HEIGHT);
            if (DevicePrinter.POSITION_NONE.equals(position)) {
                out.write(ESCPOS.BAR_POSITIONNONE);
            } else {
                out.write(ESCPOS.BAR_POSITIONDOWN);
            }
            out.write(ESCPOS.BAR_HRIFONT1);
            out.write(ESCPOS.BAR_CODE02);
            out.write(DeviceTicket.transNumber(DeviceTicket.alignBarCode(code,13).substring(0,12)));
            out.write(new byte[] { 0x00 });

            out.write(getNewLine());
        }else if(DevicePrinter.BARCODE_CODE128.equals(type)){
            out.write(getNewLine());

            out.write(ESCPOS.BAR_HEIGHT);
            if (DevicePrinter.POSITION_NONE.equals(position)) {
                out.write(ESCPOS.BAR_POSITIONNONE);
            } else {
                out.write(ESCPOS.BAR_POSITIONDOWN);
            }
            if (code.length() > 12){
                out.write(ESCPOS.BAR_WIDTH);    
            }
            out.write(ESCPOS.BAR_HRIFONT1);
            out.write(ESCPOS.BAR_CODE128);
            byte[] transCode = Codes.transCode128(code);
            byte lengthByte = new Integer(transCode.length+2).byteValue();
            byte[] length = {lengthByte};
            out.write(length);
            out.write(ESCPOS.BAR_CODE128TYPE);
            out.write(transCode);
            out.write(new byte[] { 0x00 });
        }
    }
   
    public byte[] transImage(BufferedImage image) {
        
            CenteredImage centeredimage = new CenteredImage(image, getImageWidth());

        // Imprimo los par\u00e1metros en cu\u00e1druple
        int iWidth = (centeredimage.getWidth() + 7) / 8; // n\u00famero de bytes
        int iHeight = centeredimage.getHeight();
        
        // Array de datos
        byte[] bData = new byte[getImageHeader().length + 4 + iWidth * iHeight];
        
        // Comando de impresion de imagen
        System.arraycopy(getImageHeader(), 0, bData, 0, getImageHeader().length);
        
        int index = getImageHeader().length;
        
        // Dimension de la imagen
        bData[index ++] = (byte) (iWidth % 256);
        bData[index ++] = (byte) (iWidth / 256);
        bData[index ++] = (byte) (iHeight % 256);
        bData[index ++] = (byte) (iHeight / 256);       
        
        // Raw data
        int iRGB;
        int p;
        for (int i = 0; i < centeredimage.getHeight(); i++) {
            for (int j = 0; j < centeredimage.getWidth(); j = j + 8) {
                p = 0x00;
                for (int d = 0; d < 8; d ++) {
                    p = p << 1;
                    if (centeredimage.isBlack(j + d, i)) {
                        p = p | 0x01;
                    }
                }
                
                bData[index ++] = (byte) p;
            }
        }        
        return bData;
    }

    protected class CenteredImage {

        private BufferedImage image;
        private int width;

        public CenteredImage(BufferedImage image, int width) {
            this.image = image;
            this.width = width;
        }

        public int getHeight() {
            return image.getHeight();
        }

        public int getWidth() {
            return width;
        }

        public boolean isBlack(int x, int y) {

            int centeredx = x + (image.getWidth() - width) / 2;
            if (centeredx < 0 || centeredx >= image.getWidth() || y < 0 || y >= image.getHeight()) {
                return false;
            } else {
                int rgb = image.getRGB(centeredx, y);

                int gray = (int)(0.30 * ((rgb >> 16) & 0xff) +
                                 0.59 * ((rgb >> 8) & 0xff) +
                                 0.11 * (rgb & 0xff));

                return gray < 128;
            }
        }
    }
}
