/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

import javax.swing.JComponent;

public interface DeviceDisplay {

    // INTERFAZ DESCRIPCION
    public String getDisplayName();
    public String getDisplayDescription();
    public JComponent getDisplayComponent();
    
    // INTERFAZ VISOR    
    public void writeVisor(int animation, String sLine1, String sLine2);
    public void writeVisor(String sLine1, String sLine2);
    public void clearVisor();
}
