/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.awt.image.BufferedImage;

import javax.swing.JComponent;

import com.openbravo.pos.printer.*;

public class DevicePrinterPlain implements DevicePrinter  {
    
    private static final byte[] NEW_LINE = {0x0D, 0x0A}; // Print and carriage return
      
    private PrinterWritter out;
    private UnicodeTranslator trans;
    
    // Creates new TicketPrinter
    public DevicePrinterPlain(PrinterWritter CommOutputPrinter) throws TicketPrinterException {

        out = CommOutputPrinter;
        trans = new UnicodeTranslatorStar(); // The star translator stands for the 437 int char page
    }
   
    public int getPrinterType() {
        return DevicePrinter.TYPE_NONE;
    }
    public String getPrinterName() {
        return "Plain printer";
    }
    public String getPrinterDescription() {
        return out.getDescription();
    }   
    public JComponent getPrinterComponent() {
        return null;
    }
    public void reset() {
    }
    public String getSystemName() {
        return "";
      }
    
    public void beginReceipt() {
    }
    
    public void printImage(BufferedImage image) {
    }
    
    public void printBarCode(String type, String position, String code) {        
        if (! DevicePrinter.POSITION_NONE.equals(position)) {                
            out.write(code);
            out.write(NEW_LINE);
        }
    }
    
    public void beginLine(int iTextSize) {
    }
    
    public void printText(int iStyle, String sText) {
        out.write(trans.transString(sText));
    }
    
    public void endLine() {
        out.write(NEW_LINE);
    }
    
    public void endReceipt() {       
        out.write(NEW_LINE);
        out.write(NEW_LINE);
        out.write(NEW_LINE);
        out.write(NEW_LINE);
        out.write(NEW_LINE);
        out.flush();
    }
    
    public void openDrawer() {
    }

    public String checkDrawerStatus() { 
        return DevicePrinter.DRAWER_NOTAVAILABLE;
    }
}

