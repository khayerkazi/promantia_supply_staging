/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

import java.math.BigDecimal;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author adrian
 */
public class PaymentRequest {
    
    public static final int TYPE_SALE = 0;
    public static final int TYPE_REFUND = 1;
    public static final int TYPE_VOID = 2;
    
    private int type = TYPE_SALE;
    private String transactionID = null;
    private String terminalID = null;
    private String currency = null;
    private BigDecimal amount = BigDecimal.ZERO;
    private JSONObject properties;
    
    private boolean test = false;
    
    
    public PaymentRequest () {       
    }    
    
    public PaymentRequest (JSONObject json) throws JSONException {
        type = json.getInt("type");
        transactionID = json.optString("transaction");
        terminalID = json.optString("terminal");
        currency = json.optString("currency");
        amount = new BigDecimal(json.getString("amount"));
        properties = json.optJSONObject("properties");
        test = json.optBoolean("test", false); 
    }
    
    public JSONObject toJSON() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("type", type);
        obj.put("terminal", terminalID);
        obj.put("transaction", transactionID);
        obj.put("amount", amount);
        obj.put("currency", currency);
        obj.put("properties", properties);
        obj.put("test", test);
        return obj;
    }  
    
    /**
     * @return the type
     */
    public int getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * @param transactionID the transactionID to set
     */
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the terminalID
     */
    public String getTerminalID() {
        return terminalID;
    }

    /**
     * @param terminalID the terminalID to set
     */
    public void setTerminalID(String terminalID) {
        this.terminalID = terminalID;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the amount
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * @return the properties
     */
    public JSONObject getProperties() {
        return properties;
    }

    /**
     * @param properties the properties to set
     */
    public void setProperties(JSONObject properties) {
        this.properties = properties;
    }
    
    /**
     * @return the test
     */
    public boolean isTest() {
        return test;
    }

    /**
     * @param test the test to set
     */
    public void setTest(boolean test) {
        this.test = test;
    }

}
