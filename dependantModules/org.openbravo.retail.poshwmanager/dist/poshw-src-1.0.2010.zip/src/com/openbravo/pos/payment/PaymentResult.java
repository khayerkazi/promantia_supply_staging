/*
 ************************************************************************************
 * Copyright (C) 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author adrian
 */
public class PaymentResult {
    
    public static final int RESULT_SUCCESS = 0;
    public static final int RESULT_AUTHORIZATION_FAIL = 1;
    public static final int RESULT_ERROR = 2;
    
    private int result = RESULT_SUCCESS;
    private String resultCode = null;
    private String resultMessage = null;
    private String transactionID = null;
    private String authorizationID = null;
    private PaymentRequest request = null;
    private JSONObject properties = null;
    
    public JSONObject toJSON() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("result", result);
        obj.put("resultCode", resultCode);
        obj.put("resultMessage", resultMessage);
        obj.put("transaction", transactionID);
        obj.put("authorization", authorizationID);
        obj.put("request", getRequest() == null ? null : getRequest().toJSON());
        obj.put("properties", properties);
        return obj;
    }

    /**
     * @return the result
     */
    public int getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(int result) {
        this.result = result;
    }

    /**
     * @return the resultCode
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * @param resultCode the resultCode to set
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    /**
     * @return the resultMessage
     */
    public String getResultMessage() {
        return resultMessage;
    }

    /**
     * @param resultMessage the resultMessage to set
     */
    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * @param transactionID the transactionID to set
     */
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the authorizationID
     */
    public String getAuthorizationID() {
        return authorizationID;
    }

    /**
     * @param authorizationID the authorizationID to set
     */
    public void setAuthorizationID(String authorizationID) {
        this.authorizationID = authorizationID;
    }

    /**
     * @return the properties
     */
    public JSONObject getProperties() {
        return properties;
    } 

    /**
     * @param properties the properties to set
     */
    public void setProperties(JSONObject properties) {
        this.properties = properties;
    }

    /**
     * @return the request
     */
    public PaymentRequest getRequest() {
        return request;
    }

    /**
     * @param request the request to set
     */
    public void setRequest(PaymentRequest request) {
        this.request = request;
    }
}
