/*
 ************************************************************************************
 * Copyright (C) 2012-2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PrinterWritterFile extends PrinterWritter {
    
    private static final Logger logger = Logger.getLogger(PrinterWritterFile.class.getName());

    private static final int BUFFER_SIZE = 2048;

    private final String m_sFilePrinter;

    private OutputStream m_out;

    public PrinterWritterFile(String sFilePrinter) {
        m_sFilePrinter = sFilePrinter;
        m_out = null;
    }

    @Override
    public String getDescription() {
        return "File port: " + m_sFilePrinter + ".";
    }

    @Override
    public void write(byte[] data) {
        try {
            if (m_out == null) {
                // Do not set append == true,
                m_out = new BufferedOutputStream(new FileOutputStream(m_sFilePrinter), BUFFER_SIZE); 
            }
            m_out.write(data);
        } catch (IOException e) {
            logger.log(Level.SEVERE, null, e);
        }
    }

    @Override
    public int read() {
        InputStream m_in = null;
        try {
            m_in = new BufferedInputStream(new FileInputStream(m_sFilePrinter), BUFFER_SIZE);
            return m_in.read();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
            return -1;
        } finally {
            try {
                if (m_in != null) {
                    m_in.close();
                }
            } catch (IOException ex) {
                logger.log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void flush() {
        try {
            if (m_out != null) {
                m_out.flush();
                m_out.close();
                m_out = null;
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void close() {
        try {
            if (m_out != null) {
                m_out.flush();
                m_out.close();
                m_out = null;
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, null, e);
        }
    }
}
